// opciones del menu desde el json
fetch("menu.json")
  .then(res => res.json())
  .then(datos => dibujarMenu(datos.menu));



// crea el enlace de una opcion; si tiene enlace se abre en el iframe
function crearEnlace(opcion) {
  const a = document.createElement("a");
  a.textContent = opcion.nombre;
  if (opcion.enlace) {
    a.href = opcion.enlace;
    a.target = "contenido";
  } else {
    a.tabIndex = 0;
  }
  return a;
}



// dibuja el menu y sus submenus con los datos del json
function dibujarMenu(lista) {
  const menu = document.getElementById("menu");

  lista.forEach(opcion => {
    const li = document.createElement("li");
    li.appendChild(crearEnlace(opcion));

    if (opcion.submenu) {
      const ul = document.createElement("ul");
      ul.className = "submenu";
      opcion.submenu.forEach(sub => {
        const subLi = document.createElement("li");
        subLi.appendChild(crearEnlace(sub));
        ul.appendChild(subLi);
      });
      li.appendChild(ul);
    }

    menu.appendChild(li);
  });
}
