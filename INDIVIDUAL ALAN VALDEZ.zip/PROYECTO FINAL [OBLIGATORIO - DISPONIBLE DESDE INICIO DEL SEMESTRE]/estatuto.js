// texto del estatuto organico de la uasd
const ESTATUTO = `
PRESENTACIÓN
La Rectoría de la Universidad Autónoma de Santo Domingo presenta, a la
comunidad universitaria, nacional e internacional y al país, una reimpresión del Estatuto Orgánico vigente. Se trata de una copia fiel e idéntica
a su original. El conocimiento de una entidad es un vínculo con ella. Sirve
para establecer una relación amigable. Esta nueva impresión ayudará a
que más personas conozcan con profundidad a esta Academia.
El presente texto estatutario es el resultado de la reforma aprobada
por el Claustro Mayor en sus sesiones del 25 de enero y el 8 de febrero
de 2012, una de las más amplias realizadas hasta la fecha.
Como podrá apreciar el lector, la reforma del año 2012 introdujo nuevos paradigmas relacionados con la duración de la gestión, las elecciones
simultáneas, la prohibición de la reelección consecutiva en todos los cargos, la dedicación exclusiva de los funcionarios electos y la creación de un
nuevo sistema de selección y contratación del personal académico y administrativo que privilegia el concurso y la contratación a tiempo completo.
En vista de que son muchas y muy significativas las modificaciones
contenidas en este Estatuto, con su puesta en vigencia se crearon nuevas
formas administrativas, nuevos estilos de dirección y nuevos procedimientos universitarios, razón por la cual es necesaria la más amplia difusión de
este texto normativo.
Con la presente reimpresión del presente Estatuto Orgánico se procura
fortalecer el desarrollo institucional de la Universidad Primada de América. Esta gestión está empeñada en que todos sus órganos e instancias

velen para que las decisiones y actuaciones de todos, comenzando con
las del suscrito, se ajusten a las normas establecidas en este documento
fundamental de la vida universitaria.
Esta Rectoría hace un ferviente llamado a los universitarios y universitarias, incluyendo a los gremios y grupos organizados, para que se esfuercen por conocer y aplicar el Estatuto Orgánico, la principal expresión jurídica interna que, de seguro, traerá más unidad en la familia universitaria.
Para cumplir la misión y la visión de la Universidad es necesario acogerse
a las mejores prácticas, transitar el camino de la mejora continua y elevar
así la calidad y la eficiencia con sentido de relevancia, pertinencia social y
trascendencia histórica.

Dr. Iván Grullón Fernández
Rector

ÍNDICE

CAPÍTULO 1
De la Universidad
Conceptos y principios fundamentales

Artículo 1
La Universidad Autónoma de Santo Domingo es continuación de la
Universidad de Santo Tomás de Aquino, designada Pontificia Universidad de Santo Domingo, fundada el 28 de octubre de 1538 mediante
la Bula “In Apostolatus Culmine” de su Santidad el Papa Paulo III. Declarada Real, por Real Cédula del Rey Felipe V del 27 de julio de 1734.
Es una institución pública y descentralizada del Estado, con autonomía garantizada por la Constitución de la República, dotada de plena
personería jurídica de acuerdo con la Ley 5778, promulgada por el
Poder Ejecutivo el 31 de diciembre de 1961, y ratificada mediante la
Ley 139-01 del 13 de agosto de 2001, que se sustenta en un modelo
de Universidad Nacional.

Artículo 2
La Universidad es una institución que une a profesores, estudiantes y
servidores de apoyo a la labor académica, con el propósito de dar cumplimiento a la misión y la visión universitarias.

Artículo 3
La Universidad Autónoma de Santo Domingo es un patrimonio social público de alto interés estratégico que forma parte del Sistema Nacional
de Educación Superior Estatal, integrada por la Sede Central, Recintos,
Centros y Subcentros Universitarios, esparcidos en la geografía del país

y en el exterior, con centralización normativa y descentralización operativa
e interdependientes, que se gestiona bajo el régimen de autonomía con
responsabilidad.
Párrafo.- Los Centros Universitarios existentes podrán alcanzar la categoría de Recintos de acuerdo con su nivel de desarrollo académico,
administrativo y financiero, conforme a un reglamento que aprobará el
Consejo Universitario para tal fin.

Artículo 4
El modelo educativo institucional de la Universidad Autónoma de Santo
Domingo está sustentado en la docencia, la investigación y la extensión;
busca fortalecer el desarrollo de una conciencia crítica, el pensamiento
reflexivo y creativo, así como las demás funciones y actividades que se
requieren para el cumplimiento de su misión.

Artículo 5
Ningún organismo o persona podrá usar el nombre ni los símbolos de
la Universidad, ni emplear su condición de miembro de la misma, para
satisfacer intereses particulares de orientación partidaria, económica, religiosa, o de otra índole.

Artículo 6
La vida universitaria se desenvolverá conforme a un espíritu de democracia, justicia y solidaridad humana. Estará abierta a todas las corrientes del
pensamiento, las cuales serán expuestas y analizadas de manera rigurosamente científica.

MISIÓN, VISIÓN Y VALORES

Artículo 7
Es misión de la Universidad:
a) contribuir a elevar los niveles culturales de la sociedad;
b) buscar la verdad, la proyección de un mejor porvenir de la sociedad
dominicana y el afianzamiento de sus auténticos valores;
c) formar criticamente investigadores, profesionales y técnicos en las
ciencias, las humanidades y las artes, necesarios y eficientes para
coadyuvar a las transformaciones que demanda el desarrollo nacional
sostenible;
d) contribuir a la formación de una conciencia crítica-reflexiva de la sociedad dominicana, no dependiente, enmarcada solidariamente en los
principios sustentados por los pueblos que luchan por su independencia y bienestar;
e) promover y desarrollar investigaciones científicas, humanísticas, tecnológicas y artísticas, tendentes a mejorar las condiciones materiales y
espirituales de la sociedad dominicana; a desentrañar las causas esenciales del subdesarrollo, la dependencia y los problemas que como
consecuencia de ello le afecten, así como, sugerir, aportar soluciones y
contribuir a aumentar el acervo de conocimientos de la humanidad;
f) difundir los ideales de la cultura de paz, progreso, justicia social, equidad de género y respeto a los derechos humanos, a fin de contribuir a
la formación de una conciencia colectiva basada en esos valores;
g) desarrollar sus funciones de acuerdo a la ética y el rigor científico e
intelectual;

h) fomentar en el seno de la Institución un espíritu permanente de crítica
y autocrítica con miras al cabal cumplimiento de la misión universitaria;
i) promover la racionalidad filosófica, científica, la sensibilidad artística, la
innovación y la creatividad; y
j) impulsar la defensa de los recursos naturales y del medio ambiente.

Artículo 8
La Universidad tiene como visión:
Ser una institución de excelencia y liderazgo académico, gestionada con
eficiencia, acreditada nacional e internacionalmente, con un personal docente, investigador, extensionista y egresados de alta calificación; creadora de conocimientos científicos y nuevas tecnologías; sustentada en
valores; reconocida por su contribución al desarrollo humano con equidad
y al desarrollo de una sociedad democrática y solidaria.

Artículo 9
La Universidad está orientada hacia el respeto y la defensa de la dignidad humana y se sustenta en los siguientes
valores:
a) solidaridad;
b) transparencia;
c) verdad;
d) igualdad;
e) libertad;
f) equidad;
g) tolerancia;
h) paz;
i) responsabilidad; y
j) convivencia.

Artículo 10
Las actividades de la Universidad deben dirigirse fundamentalmente hacia:
a) el incremento de la educación, con el fin de servir a los intereses de
la nación;
b) la preparación de profesionales en el número adecuado para satisfacer
las necesidades de la sociedad;
c) el adiestramiento técnico especializado, de acuerdo con las exigencias
de desarrollo del país;
d) la investigación como medio para la enseñanza, la comprensión de los
métodos científicos y el establecimiento de la verdad;
e) el desarrollo de actividades de extensión cultural y científica;
f) la capacitación del personal docente, de investigación y de extensión
necesarios para la Universidad y el país;
g) la promoción, organización y estímulo de la investigación científica, humanística y tecnológica de problemas nacionales y universales;
h) la afirmación, desde su plano rector, de los valores espirituales y de los
derechos humanos; e
i) el fortalecimiento del intercambio cultural con las instituciones universitarias de todas partes del mundo para participar en la tarea universal
de la investigación científica y desarrollar la comprensión y la cooperación internacionales.

Artículo 11
Los criterios que deben regir la Universidad para alcanzar
las metas descritas en el artículo anterior, deben ser, entre
otros:
a) un criterio nacional, regional y mundial que haga prevalecer los valores
propios, las necesidades de nuestro desarrollo y la vinculación con el
resto del mundo;
b) un criterio moral que obligue a la Universidad, como institución, y a
cada uno de sus miembros, como tales, a respetar y defender la verdad, la libertad, la dignidad humana y los principios éticos;
c) un criterio de autonomía que involucre el mantenimiento del fuero universitario y una completa independencia en los ámbitos administrativo,
educativo, político, religioso y económico;
d) un criterio cualitativo en todos los órdenes, tanto en lo referente a
la preparación académica, como a la formación del ser humano, que
estimule la capacidad de pensar, comprender y desarrollar una función
útil para la sociedad;
e) un criterio cuantitativo cuyo fin sea educar a un número cada vez mayor
de personas; y
f) un criterio económico que contribuya al mejor aprovechamiento de
los recursos materiales y humanos, a fin de permitir a la sociedad un
máximo rendimiento con la menor inversión de sus disponibilidades
financieras y sin duplicidad de esfuerzos.

CAPÍTULO II
De la Estructura de la Universidad

Artículo 12
La Universidad está integrada por:
a) sus instituciones culturales, científicas, artísticas y técnicas;
b) el personal académico (docente, investigador y extensionista) de grado y posgrado, activo y jubilado;
c) los estudiantes debidamente matriculados, de grado y posgrado;
d) el personal administrativo, activo y jubilado; y
e) los egresados de la Universidad.

Artículo 13
La Universidad tiene una estructura múltiple, compuesta por un conjunto
de organismos que actúan interrelacionados y que en cada caso constituyen expresiones sistémicas para los fines y funciones. La estructura está
integrada de la siguiente manera:
a) Estructura de gobierno:
La estructura de gobierno está compuesta por los organismos que tienen
por misión trazar las políticas y adoptar las decisiones que convengan
para los fines de la Institución. Estos organismos son de dos categorías:
Colegiados y Unipersonales. Están contenidos en este Estatuto y en los
Reglamentos aprobados por el Consejo Universitario.

Son colegiados los siguientes:
a) el Claustro Mayor;
b) el Claustro Menor;
c) el Consejo Universitario;
d) las Asambleas de Facultad;
e) los Consejos Directivos de Facultad;
f) las Asambleas de Recintos y Centros;
g) los Consejos Directivos de Recintos y Centros;
h) las Asambleas de las Escuelas;
i) los Subconsejos Directivos de las Escuelas;
j) los Consejos de los Institutos;
k) la Asamblea de Cátedra;
l) el Consejo General de Posgrado de la Universidad;
m) el Consejo General de Investigaciones Científicas de la Universidad;
n) el Consejo General de Extensión de la Universidad;
ñ) las Comisiones de Investigación por Facultad;
o) el Consejo de Posgrado de Facultad; y
p) el Comité Académico de Posgrado por Escuela.
Son unipersonales los siguientes:
a) la Rectoría y Vicerrectorías;
b) la Secretaría General;
c) los Decanatos y Vicedecanatos;
d) las Direcciones y Subdirecciones de los Recintos, Centros y Subcentros;
e) las Direcciones de las Escuelas;
f) las Direcciones de los Institutos;
g) la Coordinación de Cátedra;
h) la Dirección General de Postgrado;
i) la Dirección General de Investigaciones Científicas;
j) las Direcciones de Posgrado por Facultad; y
k) las Direcciones de Investigaciones por Facultad.

b) Estructura académica
La estructura académica de la Universidad está compuesta, en su contenido, por la oferta curricular aprobada, y en su forma, por el conjunto de
unidades que llevan a cabo, en estrecha relación, los trabajos de docencia
en el grado y el posgrado, la investigación y la extensión, para validar sus
prácticas y acrecentar el acervo cultural.
Las unidades que llevan a cabo la oferta curricular de la Universidad corresponden a los siguientes niveles:
a) nivel Técnico Superior;
b) nivel de Grado; y
c) nivel de Posgrado.
c) Estructura administrativa
La estructura administrativa de la Universidad está compuesta por las
unidades de administración que realizan tareas que sirven de apoyo al
desarrollo de las funciones de docencia, investigación y extensión y al
logro de los fines de la Institución.

Artículo 14
La función académica de la Universidad se llevará a cabo, fundamentalmente, a través de las Facultades, Recintos, Centros y Subcentros:
A) las Facultades son las siguientes:
a) Humanidades;
b) Ciencias;
c) Ciencias Económicas y Sociales;
d) Ciencias Jurídicas y Políticas;
e) Ingeniería y Arquitectura;
f) Ciencias de la Salud;
g) Ciencias Agronómicas y Veterinarias;

h) Artes; e
i) Ciencias de la Educación.
B) los Recintos, Centros y Subcentros serán aprobados por el Claustro
Menor a propuesta del Consejo Universitario.
Párrafo:.- Los Recintos, Centros y Subcentros existentes, así como los
que sean creados, se denominarán: Universidad Autónoma de Santo Domingo, y a continuación el nombre Recinto, Centro o Subcentro, según
corresponda, y el nombre de la ciudad donde están ubicados.

Artículo 15
Las resoluciones de los organismos colegiados serán ejecutadas por sus
máximos ejecutivos:
a) las del Claustro Mayor, las del Claustro Menor y las del Consejo Universitario por el Rector o Rectora;
b) las de las Asambleas y de los Consejos Directivos de las Facultades por
los Decanos/as;
c) las de las Asambleas y de los Subconsejos Directivos de las Escuelas
por los Directores/as; y
d) las de las Asambleas y los Consejos Directivos de los Recintos por sus
máximos ejecutivos y las de los Centros por los Directores/as.

Artículo 16
Las Facultades son las unidades fundamentales de la Universidad, constituidas por un mínimo de dos escuelas. Su función docente, de investigación y extensión está organizada por:
a) las Cátedras;
b) las Escuelas; y
c) los Institutos.

Párrafo:.- Cada Facultad funciona con una estructura orgánica conforme
a sus peculiares necesidades de enseñanza teórica, práctica y de investigación, así como de servicio a la comunidad.

Artículo 17
Las Escuelas son unidades académicas integradas por varias cátedras correspondientes a una misma rama de las humanidades, las
ciencias, las artes y las tecnologías, mediante las cuales y a través de
diferentes medios se desarrollan las funciones de docencia, investigación y extensión. No habrá más de una Escuela en la Universidad
para una disciplina.

Artículo 18
Cada Escuela funciona adscrita a una Facultad y su actividad académica
es desarrollada por las cátedras. Las Escuelas administran las carreras
de grado y las carreras del nivel técnico superior, coordinando las asignaturas que enseñan en las distintas Facultades. En dichas Escuelas se
originan los programas de cuarto nivel.

Artículo 19
La Cátedra es la unidad académica básica, responsable, en primera instancia, de la planificación, organización, supervisión, evaluación y control
de las funciones de docencia, investigación y extensión. Está integrada por
el profesor o profesores que tengan a su cargo una o varias asignaturas.

Artículo 20
La Universidad establece un Ciclo Básico Común obligatorio para todas las
carreras; un ciclo de formación general y un ciclo profesionalizante para
cada carrera. Un reglamento especificará la aplicación de este artículo.

Artículo 21
Los Institutos son organismos adscritos a las Facultades, destinados al
trabajo de investigación y a contribuir al perfeccionamiento de la docencia,
en coordinación con las escuelas, las cátedras y las unidades de posgrado. Su principal función es la de fomentar la búsqueda de nuevos conocimientos y tecnologías.

Artículo 22
La Universidad tendrá diversos organismos destinados a complementar
las labores que se realizan dentro de las Facultades, Recintos, Centros
y Subcentros y estarán adscritos a la Rectoría y a las diferentes Vicerrectorías, según sus funciones y afinidad, que determinará el Consejo
Universitario.

CAPÍTULO III
De la planificación del desarrollo
universitario

Artículo 23
El cumplimiento de la misión universitaria y su desarrollo integral se guían
por el proceso de planificación, realizado en sus funciones sustantivas
de docencia, investigación y extensión, así como, en su administración,
por todos sus organismos, con la participación de los diferentes sectores
internos, tomando en cuenta los planes nacionales de desarrollo y las
tendencias locales e internacionales en la educación superior, la ciencia y
la tecnología.

Artículo 24
La Oficina de Planificación Universitaria coordinará el sistema de planificación de la Universidad, velará por su actualización y evaluación, diseñará
y mantendrá actualizado el sistema de seguimiento y control institucional,
y emitirá su opinión previo a los cambios que se propongan realizar en la
estructura orgánica y curricular de la Institución. Su estructura y demás
funciones están definidas en un Reglamento.

CAPÍTULO IV
Del Claustro Universitario

Artículo 25
De acuerdo con la naturaleza de los asuntos a tratar, habrá un Claustro
Mayor y un Claustro Menor.

Artículo 26
El Claustro Mayor es la autoridad máxima de la Universidad Autónoma
de Santo Domingo. Está integrado por el personal académico en servicio activo a partir de la categoría de Adscrito, los profesores meritísimos
(activos o jubilados), los delegados estudiantiles, en un treinta y tres
punto treinta y tres por ciento (33.33%) del total de los miembros del
Claustro. A ese conjunto se le agregan los representantes del personal
administrativo, en un dos por ciento (2%) del total de miembros del
organismo.
Párrafo I.- Los representantes estudiantiles en el Claustro Mayor y los
demás organismos de cogobierno, deben reunir, las siguentes condiciones:
1. Estar oficialmente inscritos en la universidad. 2. No ser alumnos repitientes.
3. Tener aprobado por lo menos el 30% de los créditos de sus respectivas
carreras. 4. Tener un índice académico acumulado de 80 puntos o más.
Párrafo II.- Cuando el Claustro Mayor sesione con la finalidad de elegir
a las máximas autoridades de la Universidad, su composición estará
integrada por el personal académico en servicio activo a partir de la
categoría de Adscrito, los profesores meritísimos (activos o jubilados),
los profesores ayudantes con más de dos años en servicio activo en una

proporción igual al 2% del total de los profesores, los delegados estudiantiles, en una proporción igual al 5% del total de los profesores, y
los representantes del personal administrativo en una proporción igual
al 1% del total de los profesores.
Párrafo III:.- Para los casos de elección de autoridades correspondientes a los demás organismos de la Universidad, rige la misma composición indicada en el párrafo anterior, con excepción de la participación del personal administrativo, que sólo está establecida para el
Claustro Mayor.

Artículo 27
El quórum requerido para que el Claustro Mayor pueda sesionar válidamente en una primera convocatoria es de no menos de un sesenta por
ciento (60%) de los miembros inscritos. En caso de que el quórum no se
completare dentro de la hora siguiente a la señalada para la sesión, se
hará una segunda convocatoria, y para sesionar válidamente se requerirá
la participación de más de la mitad de sus miembros inscritos. Para la
aprobación válida de sus decisiones se requiere más de la mitad de los
votos depositados, salvo los casos en que este Estatuto establezca una
proporción distinta.
Párrafo I.- Para que las elecciones del Rector y de los Vicerrectores
sean válidas, deben votar, por lo menos, el sesenta por ciento (60%)
de los miembros inscritos en el Claustro Mayor, y el triunfo lo obtendrán
quienes alcancen más de la mitad de los votos depositados, es decir, la
mayoría absoluta. El mismo porcentaje de votación se requiere en los
demas organismos eleccionarios.
Párrafo II.- En caso de que ningún candidato alcance la mayoría absoluta, los dos candidatos más votados irán a una segunda vuelta, y el triunfo
lo obtendrá aquel de los dos que alcance más votos, es decir, la mayoría
simple.

Artículo 28
Son atribuciones del Claustro Mayor:
a) elegir al Rector/a y a los Vicerrectores/as en elecciones celebradas
mediante votación en urnas colocadas en las diferentes Facultades,
Recintos, Centros y Subcentros, en horario de 8:00 a.m. a 8:00 p.m. y
regidas por un reglamento aprobado por el Consejo Universitario;
b) revocar de sus funciones, previa formalización de expedientes por parte del Consejo Universitario, al Rector/a y a los Vicerrectores/as, para
lo cual será necesario el voto no inferior a las dos terceras partes
(2/3) del total de sus miembros inscritos.
Párrafo.- En caso de acusación contra el/la Rector/a, presidirá el
Claustro Mayor el/la Vicerrector/a de más antigüedad en el servicio académico. En ausencia de los/las Vicerrectores/as, presidirá el Claustro
Mayor el/la decano/a de mayor antigüedad en el servicio académico;
c) conocer y pronunciarse sobre situaciones extraordinarias que puedan
afectar el normal desenvolvimiento de la Universidad, motivadas por
factores internos o externos;
d) decidir sobre la modificación del Estatuto en lo concerniente a la Filosofía, Principios y Fines de la Universidad, con el voto favorable de las
dos terceras partes (2/3) de sus miembros inscritos;
e) crear y suprimir, previa recomendación del Claustro Menor o del Consejo Universitario, las Vicerrectorías y Facultades para el mejor desarrollo
de la Institución;
f) decidir sobre los demás asuntos que no han sido expresamente atribuidos a otra autoridad u organismo; y
g) el Claustro Mayor puede ser convocado por el Claustro Menor, el Consejo Universitario, el/la Rector/a o por lo menos el veinte por ciento

(20%) de sus miembros. En todo caso, la convocatoria deberá detallar
la agenda que la motiva.
Párrafo.- El/la Rector/a deberá convocar al Consejo Universitario,
para informarle, dentro de las 72 horas de recibida la convocatoria al
Claustro y fijar la fecha para su celebración en un plazo no mayor de
30 días, luego de haberse recibido la solicitud.

Artículo 29
El Claustro Menor está integrado por el Consejo Universitario, los profesores elegidos para ese fin en un sesenta y seis punto sesenta
y siete por ciento (66.67%) del organismo y la representación de
los estudiantes en el treinta y tres punto treinta y tres por ciento
(33.33%) de dicho organismo. A ese conjunto se le agregan los representantes del personal administrativo en un dos por ciento (2%)
del total de integrantes del organismo. El Claustro Menor tendrá una
composición equivalente al quince por ciento (15%) del Claustro Mayor, en una cantidad de miembros no menor de trescientos (300) y no
mayor de quinientos (500).
Párrafo I.- Los profesores serán elegidos mediante sufragio universal convocado para tal fin y con base en un reglamento aprobado al
efecto.
Párrafo II.- La representación profesoral se elegirá en proporción al
universo profesoral de cada Facultad.

Artículo 30
El quórum requerido para que el Claustro Menor pueda sesionar válidamente en una primera convocatoria es de no menos de un sesenta por
ciento (60%) de sus miembros inscritos. En caso de que el quórum no se
completare dentro de la hora siguiente de la señalada para la sesión, se
hará una segunda convocatoria, y para sesionar válidamente se reque-

rirá la presencia de más de la mitad de sus miembros inscritos. Para la
aprobación válida de sus decisiones se requiere más de la mitad de los
votos depositados, salvo los casos en que este Estatuto establezca una
proporción distinta.
Párrafo I.- El Claustro Menor se reunirá ordinariamente al inicio de cada
semestre académico y extraordinariamente en los casos en que las atribuciones que le confiere este Estatuto lo requieran, convocado por el/
la Rector/a, el Consejo Universitario o por lo menos el veinte por ciento
(20%), de sus miembros inscritos.
Párrafo II.- Las decisiones del Claustro Menor podrán ser apeladas ante
el Claustro Mayor a solicitud del 20% de sus integrantes.

Artículo 31
Son atribuciones del Claustro Menor:
a) decidir sobre reformas al Estatuto Orgánico por el voto favorable de
las dos terceras partes (2/3) de sus miembros inscritos, a excepción
de aquellos aspectos que son reservados al Claustro Mayor;
b) proponerle al Claustro Mayor la supresión y creación de las Vicerrectorías y Facultades, para el mejor desenvolvimiento de la Universidad;
c) conocer la memoria anual que presentará el/la Rector/a;
d) otorgar el título de Doctor Honoris Causa a las personas merecedoras de tal distinción por las obras que hayan realizado en favor del
progreso y la cultura del país y/o de la humanidad. La solicitud debe
ser motivada e ir al Consejo Universitario, previa recomendación del
Consejo Directivo de la Facultad correspondiente;
e) instruir al Consejo Universitario para que ejecute los acuerdos y resoluciones adoptadas por este organismo;

f) acusar, con el voto favorable de las dos terceras partes (2/3), ante el
Claustro Mayor al Rector o a los Vicerrectores si faltaren gravemente al
cumplimiento de sus deberes y observaren mala conducta notoria;
g) aprobar el Plan Estratégico de Desarrollo de la Institución y las políticas del período de gobierno de las autoridades electas;
h) crear y suprimir Recintos, Centros y Subcentros a propuesta del Consejo Universitario.

CAPÍTULO V
Del Consejo Universitario

Artículo 32
El Consejo Universitario lo componen, con derecho a voz y voto, el
Rector/a, quien lo presidirá, los Vicerrectores/as, los Decanos/as, un
representante de los Recintos Universitarios, un representante de los
Centros Universitarios, los delegados/as estudiantiles, dos representantes del gremio profesoral, un representante del gremio de los trabajadores/as de apoyo a las labores académicas. La representación
estudiantil será de un 33.33% de la totalidad de los miembros del
Consejo. El/la Secretario/a General de la Universidad es el Secretario/a
del Consejo, con voz, pero sin voto.
Párrafo.- La elección de la representación estudiantil, profesoral y de los
servidores de apoyo a la labor académica será determinada a través de
los reglamentos correspondientes.

Artículo 33
El Consejo Universitario debe reunirse, ordinariamente, dos veces al
mes, convocado por el/la Rector/a, y extraordinariamente, en todas
las ocasiones en que las atribuciones que le confiere este Estatuto lo
requieran, convocado por el/la Rector/a, por un/a Vicerrector/a o por
dos de sus miembros. Deliberará válidamente con las dos terceras
partes (2/3) de sus miembros y adoptará sus acuerdos por la mayoría absoluta de los presentes. En caso de empate, decidirá el voto de
quien presida la sesión.

Artículo 34
Son atribuciones del Consejo Universitario:
a) aprobar y coordinar los planes de estudios y de funcionamiento de las distintas unidades académicas de la Universidad, elaborados por los Consejos
Directivos de las Facultades y aprobados por la Asamblea de cada Facultad;
b) reglamentar y supervisar el desenvolvimiento de las actividades administrativas y fiscalizar los ingresos y gastos de la Institución;
c) reglamentar todo lo referente a matrículas, inscripciones, asistencia,
exámenes, investiduras, títulos y actos académicos de la Universidad;
d) aprobar las colaciones de estudios de acuerdo con las normas internas
de cada Facultad y declarar equivalencias de estudios hechos en el
extranjero, previa consideración de los antecedentes de cada caso, las
recomendaciones del Consejo Directivo de la Facultad correspondiente
y tomando en cuenta los convenios con instituciones extranjeras;
e) reglamentar el régimen disciplinario de los profesores, empleados y
estudiantes. Sin embargo, en caso de que la sanción contra uno o más
estudiantes sea impugnada por el máximo organismo estudiantil, la
decisión final corresponderá al Claustro Menor;
f) acusar ante el Claustro Mayor Universitario al/la Rector/a o a los/las
Vicerrectores/as, si faltaren en el cumplimiento de sus deberes u observaren mala conducta notoria;
g) fijar las tarifas de los derechos que deberán pagar los estudiantes
y graduandos de la Universidad por concepto de matrícula, examen,
expedición de títulos o por cualesquiera otros motivos;
h) nombrar los profesores, previo cumplimiento de los requisitos establecidos por las Facultades y los reglamentos que han sido aprobados por
el Consejo Universitario;

i) nombrar, con calidad de meritísimos, a los profesores titulares de relevante labor, con un mínimo de diez años de docencia, previo informe
de la Asamblea de Facultad correspondiente. Los profesores meritísimos serán investidos en un acto académico solemne y podrán continuar sirviendo a la Universidad;
j) aprobar la organización y reglamentación de nuevas Escuelas e Institutos, propuestas por los Consejos Directivos y las Asambleas de
Facultad, así como la reorganización, reforma o supresión de esos
organismos;
k) reglamentar los requisitos para que los profesores universitarios puedan optar por el título de Maestro/a o Doctor/a en sus Facultades respectivas;
l) autorizar al Rector o Rectora y a los/las Vicerrectores/as a dictar cátedras;
m) fijar y ajustar, dentro de los límites establecidos, en el presupuesto
universitario, las escalas de los sueldos y beneficios que correspondan
a los profesores, funcionarios y empleados de la Universidad, conforme a la naturaleza y cuantía de la labor que rinda cada uno de ellos.
La carrera administrativa tendrá como límite superior el sueldo del
Vicesecretario/a General; la carrera académica tendrá como límite superior el sueldo del Profesor Titular; y la gerencia académica tendrá
como límite superior el sueldo del Rector o Rectora;
n) contratar los servicios de extranjeros como profesores especiales,
para dictar cátedras por un período no mayor de un año, con derecho
a renovar, si fuere necesario, los contratos de acuerdo con el Estatuto
y reglamentos vigentes. Para la selección de esos profesores se solicitará la opinión favorable del Consejo Directivo de la Facultad correspondiente;
ñ) conocer del presupuesto general de la Universidad y aprobarlo, previo
informe de los organismos técnicos correspondientes;

o) conocer de los reglamentos relativos a los gastos presupuestales y
aprobarlos;
p) autorizar los gastos extraordinarios;
q) autorizar al/la Rector/a para que actúe en justicia como demandante;
r) resolver los conflictos de competencia entre los distintos organismos
universitarios;
s) conferir, por escrito, la representación de la Universidad en los casos
en que fuere necesario y en ocasión de misiones en el exterior;
t) representar a la Universidad y fijar su posición frente a la sociedad y a
la opinión pública;
u) sancionar la elección de los/as Directores/as de Escuelas e institutos
hecha por las Asambleas respectivas;
v) nombrar a los/as Directores/as de los organismos contemplados en el
artículo 22 de este Estatuto, por períodos de cuatro años, previo conocimiento de los resultados de los concursos de oposición realizados,
excepto aquellos cargos que sean de libre nombramiento;
w) crear y suprimir cargos administrativos y docentes, así como autorizar
el nombramiento de los funcionarios y empleados de la Universidad,
previo conocimiento de los resultados de los concursos de oposición
realizados.
x) nombrar edificios, estructuras e instalaciones físicas en general;
y) modificar, por causa justificada y por petición de la Asamblea de Facultad correspondiente, los jurados examinadores nombrados por los/as
Decanos/as o Directores/as de unidades académicas.

CAPÍTULO VI
De la Rectoría

Artículo 35
La Rectoría está presidida por un Rector o Rectora, que para ser electo (a) requiere ser dominicano (a), mayor de edad, en pleno ejercicio
de los derechos civiles y políticos, académico (a) en servicio activo,
con no menos de diez (10) años de carrera académica, la cual se
inicia con la categoría de adscrito (a), tener grado de maestro (a) o
doctor (a) (PhD), y haber desempeñado alguna función académica de
dirección en la UASD.
Párrafo.- El/la Rector/a prestará juramento ante el Rector/a saliente o
ante quien sustituya válidamente a éste.

Artículo 36
El/la Rector/a es el máximo ejecutivo de la Universidad y permanecerá en
sus funciones cuatro (4) años. Este período de tiempo regirá para todos
los demás funcionarios electos, y entrará en vigencia en las elecciones
del 2014.
Parrafo I.- Ningún funcionario electo podrá presentarse a la reelección
en el período siguiente a su mandato para la misma investidura.
Parrafo II.- La disposición contenida en el párrafo anterior se aplicará a
partir de los electos en febrero del 2014.

Artículo 37
En caso de renuncia, destitución, jubilación, muerte o impedimento definitivo del Rector o de la Rectora, se procederá a una nueva elección dentro
de los treinta días de producida la vacante, por el resto del período para
el cual fue elegido. Durante ese lapso ejercerá las funciones de Rector/a,
interinamente, el Vicerrector/a que obtenga el voto favorable de las dos
terceras partes del Consejo Universitario.
Párrafo.- En los casos en que sea necesario sustituir interinamente al
Rector/a, el Consejo Universitario escogerá a uno de los/as Vicerrectores/as.

Artículo 38
Son atribuciones del Rector o Rectora:
a) velar por el cumplimiento del Estatuto, de los reglamentos y resoluciones del Claustro Mayor, Claustro Menor y Consejo Universitario;
b) presidir las sesiones del Claustro Mayor, del Claustro Menor y del Consejo Universitario;
c) presidir de oficio, cuando lo considere oportuno, las sesiones de las
Comisiones y Grupos de Trabajo que no sean organismos de gobierno
y dependan directamente de la autoridad del Claustro Mayor, Claustro
Menor y Consejo Universitario;
d) representar a la Universidad y actuar por ella como demandante o
demandada en las acciones judiciales. Para actuar en Justicia como
demandante necesita la autorización del Consejo Universitario;
e) proponer al Claustro Menor la concesión del título de Doctor Honoris
Causa, a solicitud de algún Consejo Directivo de Facultad;
f) delegar funciones cuando lo estime necesario y mantener continua supervisión de la labor universitaria en todos sus aspectos, cuidando

de que los funcionarios, los profesores, los estudiantes y el personal
administrativo cumplan sus respectivas obligaciones;
g) autorizar, con su firma y la del/la Tesorero/a, las transacciones financieras de la Universidad, excepto las que, por acuerdo del Consejo Universitario, fueren delegadas a otros funcionarios u organismos. A falta de uno
o de ambos funcionarios, firmarán quienes los sustituyan legalmente;
h) disponer los gastos ordinarios, contemplados en el presupuesto y de
los extraordinarios aprobados por el Consejo Universitario;
i) resolver, de acuerdo con el Estatuto y los reglamentos vigentes, los
asuntos administrativos;
j) nombrar los encargados y empleados de los cargos de libre nombramiento;
k) autorizar con su firma los diplomas, certificados y otros documentos que
otorgue el Consejo Universitario. Los títulos serán firmados, además,
por el/la Decano/a o el/la Director/a de la unidad académica correspondiente, y registrados por el/la Secretario/a General de la Universidad;
l) mantener informado al Consejo Universitario acerca de las principales
actividades de la Universidad;
m) impulsar iniciativas para el mejoramiento de la Institución;
n) rendir anualmente al Claustro Menor una Memoria sobre la labor de
la Universidad. En esta Memoria, propondrá, además, las mejoras o
reformas proyectadas;
ñ) asumir cualquier función de carácter administrativo no confiada a otro
funcionario u organismo;
o) suspender a cualquier funcionario o empleado administrativo por faltas
graves, con obligación de someter el caso, en el término de quince
(15) días, al organismo correspondiente para que sea conocido; y

p) llamar en auxilio la fuerza pública en caso de que la seguridad personal
de los universitarios y universitarias y los bienes de la Institución se
encuentren en peligro.

Capítulo VII:
De los Vicerrectores

Artículo 39
La Universidad cuenta con cuatro Vicerrectores/as, elegidos por el Claustro Mayor, quienes deberán reunir las mismas condiciones requeridas
para ser Rector o Rectora y agotarán el mismo período que éste. Los/as
Vicerrectores/as son: Docente, de Investigación y Posgrado, de Extensión
y Administrativo. Asumen funciones contenidas en este Estatuto y las que
el /la Rector/a les asigne.

Artículo 40
Son funciones del Vicerrector/a Docente:
a) diseñar, en coordinación con las diferentes estructuras docentes, las
políticas relacionadas con la docencia, presencial, semipresencial, virtual y a distancia, y presentarlas al Consejo Universitario para su aprobación;
b) mantener una supervisión y adecuación permanentes de los programas de la educación presencial, de la educación semipresencial, de la
educación virtual y a distancia en general de los estudios de grado;
c) velar por la actualización del personal docente de la Institución;
d) tener un inventario e información actualizada de todos los programas
y resultados semestrales de la educación presencial, de la educación
virtual y a distancia en general y otras modalidades de enseñanza de
la Institución;
e) dirigir todos los asuntos relacionados con la docencia de grado;

f) presidir la Comisión de Asuntos Docentes del Consejo Universitario;
g) evaluar el desarrollo de la docencia y los aspectos relativos a su normal desenvolvimiento;
h) velar por el cumplimiento de la Carrera Académica;
i) presentar un informe al final de cada semestre de la labor de su Vicerrectoría;
j) articular la docencia con la investigación y la extensión; y
k) cumplir con las demás funciones asignadas por el Consejo Universitario
o el/la Rector/a.

Artículo 41
Son funciones del Vicerrector/a de Investigación y Posgrado:
a) diseñar, en coordinación con las diferentes estructuras de investigación y posgrado, las políticas relacionadas con el área de Investigación y posgrado y presentarlas al Consejo Universitario para su
aprobación;
b) presidir el Consejo General de Investigaciones Científicas y el Consejo
General de Posgrado;
c) mantener actualizadas las líneas de investigación, los programas y proyectos de investigación, y los programas de cuarto nivel;
d) mantener intercambios con los organismos nacionales y extranjeros
que realizan investigación científica y posgrado;
e) asegurar la integración de la investigación con la docencia y la extensión, proponiendo los instrumentos administrativos correspondientes;
f) difundir los resultados de las investigaciones científicas y de las activi-

dades de posgrado, y presentar informes semestrales de su gestión;
g) presidir la Comisión de Investigación y Posgrado del Consejo Universitario;
h) administrar el funcionamiento del Fondo General Concursable para la
Investigación de la Universidad, de acuerdo al reglamento correspondiente, y supervisar la ejecución de otros fondos y programas de investigación y de posgrado;
i) coordinar y ejecutar junto a los demás Vicerrectores/as y Decanos/as
los planes de especialización y formación del cuarto nivel;
j) gestionar el registro de propiedad intelectual (patentes, creaciones, diseños, modelos de utilidad, derechos de autor y conexos, obtenciones
vegetales, circuitos integrados, entre otros);
k) presentar informes semestrales de su gestión; y
l) cumplir con todas las demás funciones asignadas por el Consejo Universitario o por el/la Rector/a.

Artículo 42
Son funciones del Vicerrector/a de Extensión:
a) diseñar, en coordinación con las Facultades, Recintos y Centros y las
estructuras del área de extensión, los planes, programas y las políticas
de extensión para el conocimiento y la aprobación del Consejo Universitario;
b) coordinar con los organismos institucionales, los planes, programas y
actividades de extensión y servicio comunitario;
c) presidir el Consejo de Extensión y la Comisión de Extensión del Consejo
Universitario;

d) mantener actualizados los recursos de la Universidad en materia de
extensión;
e) articular la extensión con la docencia y la investigación;
f) presentar informes semestrales de su gestión; y
g) cumplir con todas las demás funciones asignadas por el Consejo Universitario o el/la Rector/a.

Artículo 43
Son funciones del Vicerrector/a Administrativo/a:
a) presentar al Consejo Universitario los planes y programas relacionados
con la elevación de la capacidad del personal administrativo;
b) supervisar los planes de seguridad social del personal docente y administrativo;
c) supervisar las actividades administrativas de la Universidad;
d) presidir la Comisión de Asuntos Administrativos del Consejo Universitario;
e) coordinar las labores de las dependencias del área administrativa;
f) ser el supervisor inmediato de todos los funcionarios administrativos;
g) velar por el cumplimiento de la Carrera Administrativa;
h) coordinar la elaboración del presupuesto anual de la Institución, y presentar informes, por lo menos cada semestre de su ejecución;
i) firmar los documentos financieros que le autorice el Consejo Universitario o le delegue el/la Rector/a; y
j) cumplir con todas las demás funciones asignadas por el Consejo Universitario o el/la Rector/a.

CAPÍTULO VIII
Del Secretario General
y el Vicesecretario General

Artículo 44
La Universidad tendrá un/a Secretario/a General y un/a Vicesecretario/a
General. La designación del Secretario/a General y del Vicesecretario/a
General corresponde al Consejo Universitario. El/la Secretario/a General permanecerá en sus funciones por el tiempo que dure el período
electivo, salvo que haya cometido faltas en sus funciones que ameriten su destitución.

Artículo 45
Para ser Secretario/a General se requiere ser dominicano/a, estar en
pleno ejercicio de sus derechos civiles y políticos, ser profesor de la
Universidad y reunir como mínimo, además, los siguientes requisitos:
una formación académica por lo menos de maestría, 8 años o más de
carrera académica y haber desempeñado algún cargo de dirección en
la Universidad.

Artículo 46
El cargo de Vicesecretario/a General será ocupado por un/a servidor/a
administrativo/a que sea profesional y que haya ascendido de acuerdo con el escalafón establecido en la Carrera Administrativa de la
Universidad.

Artículo 47
Cuando coincidan en una misma persona las calidades de profesor/a en
servicio activo y Secretario/a General o Vicesecretario/a General, éstos
solamente podrán tener docencia en las horas que no correspondan al
horario de trabajo en la Secretaría General de la Universidad.

Artículo 48
Son deberes y atribuciones del Secretario/a General:
a) preparar los asuntos y expedientes cuyo conocimiento corresponda al
Claustro Mayor, Claustro Menor y al Consejo Universitario. Asistir a las
sesiones de estos organismos y redactar las actas, así como los acuerdos que se tomaren, excepto en los casos en que estos organismos
deleguen en uno o varios de sus miembros, en calidad de Comisión
Especial, la redacción de dichos acuerdos y actas;
b) recibir, distribuir y tramitar, previo conocimiento y aprobación del Rector o Rectora, la correspondencia de la Universidad;
c) mantener, en forma organizada y bajo su vigilancia, los archivos de la
Universidad;
d) suscribir, conjuntamente con el Rector o Rectora, las actas y los acuerdos del Claustro Mayor, Claustro Menor y del Consejo Universitario, los
títulos, certificados y otros documentos que expida la Universidad; y
e) cumplir con las demás obligaciones que le asigne el Rector o el Consejo
Universitario.
Párrafo: El/la Vicesecretario/a General asumirá las funciones del
Secretario/a General en caso de su ausencia temporal. En caso de ausencia definitiva, el Consejo Universitario designará un nuevo Secretario/a
General para completar el período.

CAPÍTULO IX
De las Asambleas de Facultad

Artículo 49
La Asamblea de Facultad la constituyen: el/la Decano/a, quien la presidirá,
los profesores en servicio activo pertenecientes a la Carrera Académica,
profesores meritísimos, activos y jubilados, y los delegados estudiantiles.
La representación estudiantil será del 33.33% del total de los miembros
de la Asamblea. Será convocada con agenda específica por el/la Decano/a,
el Consejo Directivo o el 20% de sus integrantes. El/la Vicedecano/a hará
las veces de Secretario/a. Sin embargo, la composición de la Asamblea
Eleccionaria para elegir decanos y vicedecanos se regirá conforme está
establecido en el párrafo III del Artículo 26.

Artículo 50
El quórum requerido para celebrar sesión será el sesenta por ciento
(60%) del total de los miembros inscritos. Si el quórum no se completare
dentro de la hora siguiente de la señalada para la sesión, se hará una segunda convocatoria, y para sesionar válidamente se requerirá la presencia de más de la mitad de sus miembros inscritos. Las resoluciones serán
válidas cuando tengan el voto favorable de la mayoría de los miembros
presentes. La votación será secreta, salvo cuando la Asamblea misma
disponga que sea nominal y pública; esto último no será posible cuando
se trate de la elección del/la Decano/a y del Vicedecano/a.
Párrafo.- La fecha y la forma en que deberá reunirse la Asamblea serán
señaladas en el Reglamento de cada Facultad.

Artículo 51
Son atribuciones de la Asamblea de Facultad:
a) elegir el/la Decano/a y el/la Vicedecano/a;
b) hacer observaciones, por vía del/la Decano/a, a los acuerdos del Consejo Universitario que interesen a sus respectivas Facultades; sin embargo, deberán someterse finalmente al juicio del Consejo Universitario;
c) rendir informe al Consejo Universitario acerca de los asuntos sometidos por éste;
d) proponer al Consejo Universitario, por vía del/la Decano/a, las medidas
que estimare necesarias en relación con la docencia y el funcionamiento de la Facultad;
e) autorizar al/la Decano/a o su representante ante el Consejo Universitario para que se acuse ante el Claustro Mayor, al Rector/a o a los/las
Vicerrectores/as en los casos de evidencias de incumplimiento de sus
deberes o mala conducta notoria;
f) conocer de las quejas o sugerencias que formulen los estudiantes de
la Facultad a través de sus delegados;
g) aprobar su Reglamento;
h) aprobar y someter al Consejo Universitario los planes de estudios y
funcionamiento de las unidades académicas bajo su dependencia; e
i) resolver los asuntos de la Facultad que no hayan sido expresamente
atribuidos a otros organismos.

Artículo 52
Cuando las atribuciones de la Asamblea de Facultad entren en conflicto
con las del Consejo Directivo o las del Decano/a, la primera ejercerá las
atribuciones en cuestión.

CAPÍTULO X
De los Consejos Directivos de Facultad

Artículo 53
El Consejo Directivo de Facultad estará constituido por el/la Decano/a,
quien lo presidirá; el Vicedecano/a, quien funcionará como Secretario/a;
los/las Directores/as de Escuelas, de Institutos y de Posgrado pertenecientes a la Facultad, el/la Director/a de Investigación de la Facultad, tres
profesores representantes de la Asociación de Profesores de la Facultad,
y una representación estudiantil equivalente al 33.33% de la totalidad de
los miembros. También formarán parte del Consejo Directivo de Facultad
los profesores meritísimos de la Facultad.

Artículo 54
Las resoluciones y disposiciones del Consejo Directivo de Facultad deberán ser comunicadas por escrito, regularmente, a todos los miembros de
la Asamblea de la Facultad y del Consejo Universitario.

Artículo 55
Cualquier miembro del Consejo Directivo podrá apelar ante la Asamblea de
la Facultad correspondiente las disposiciones que considere arbitrarias o
contrarias al Estatuto Orgánico o a los reglamentos vigentes.

Artículo 56
Son atribuciones del Consejo Directivo de Facultad:
a) elaborar el Reglamento Interno de la Facultad y sus organismos dependientes, que será remitido a la Asamblea de la Facultad para su
aprobación o modificación;

b) reglamentar y supervisar la generación y las asignaciones de fondos y
la ejecución de las actividades administrativas de la Facultad;
c) aprobar el proyecto de presupuesto anual de la Facultad, y someterlo,
vía el/la Decano/a, al Consejo Universitario, a más tardar sesenta días
antes de la fecha en que este organismo deba conocerlo;
d) cumplir los deberes que le asignen la Asamblea de la Facultad y el
Consejo Universitario;
e) elaborar los reglamentos concernientes a las obligaciones del Cuerpo
Docente, Investigador y Extensionista de la Facultad;
f) someter al Consejo Universitario cualquier propuesta que considere de
lugar en relación con la docencia y hacerle las recomendaciones necesarias al personal docente, investigador y extensionista;
g) proponer al Consejo Universitario los títulos y certificaciones que la
Universidad puede conferir por los estudios realizados y definir el campo de ejercicio que estos títulos o certificaciones cubran, preferiblemente de acuerdo con las clasificaciones internacionales;
h) elaborar los reglamentos que regirán para la obtención de títulos académicos;
i) someter al Consejo Universitario, por la vía del/la Decano/a, las colaciones y equivalencias de estudios hechos en otras instituciones universitarias de acuerdo con los reglamentos vigentes y teniendo en cuenta
los convenios con instituciones extranjeras;
j) elaborar los planes de estudio y someterlos a la Asamblea de la Facultad coordinándolos entre sí y con los de las demás Facultades;
k) aprobar los programas de las distintas asignaturas y coordinarlos, previa recomendación de la Dirección de las Escuelas y de los Institutos
correspondientes;

l) crear los organismos y comisiones de trabajo que considere convenientes para el buen funcionamiento y cumplimiento de sus fines;
m) acusar ante la Asamblea de la Facultad al/la Decano/a y al/la
Vicedecano/a, por incumplimiento o mala conducta notorios, previa
formalización de expediente, para lo cual será necesario el voto por lo
menos de las dos terceras partes (2/3) de la matrícula del organismo;
y
n) conocer de las violaciones a las normas universitarias cometidas por
sus profesores y estudiantes, y aplicar, en primera instancia, las sanciones correspondientes según la gravedad de la falta. Los involucrados tienen el derecho de apelación por ante el Consejo Universitario.
Un reglamento especificará el procedimiento correspondiente.

CAPÍTULO XI
De los/las Decanos/as, Vicedecanos/as y
Directores/as de Escuela

Artículo 57
Habrá un/una Decano/a y un/una Vicedecano/a por cada Facultad. Para
ser Decano/a es indispensable ser dominicano, mayor de edad, estar en
pleno ejercicio de los derechos civiles y políticos, ser profesor/a en servicio activo y cumplir, además, con los requisitos mínimos siguientes: tener
al menos el grado de maestría o su equivalente, haber sido Coordinador
/a de Cátedra o haber desempeñado una función académica de dirección
y tener 10 años o más de carrera académica.

Artículo 58
El Decano/a será elegido por la Asamblea de la Facultad, convocada únicamente para ese fin. Permanecerá cuatro (4) años en sus funciones. La
elección será secreta y se tendrá por elegido al que reúna la mayoría absoluta de los votos depositados. En caso de que ningún candidato alcance
la mayoría absoluta, es decir, más de la mitad de los votos depositados
en la primera vuelta, se decidirá conforme a lo establecido en el párrafo
II del Artículo 27.

Artículo 59
En cada Facultad habrá un Vicedecano/a, encargado de la Secretaría del
Decanato y, además, con las atribuciones y funciones que le señale el
Decano. El Vicedecano/a cumplirá la misma jornada del Decano/a y le sustituirá, con todas sus atribuciones, en caso de ausencia temporal de éste.

Artículo 60
Para ser Vicedecano/a se requieren las mismas condiciones exigidas para
ser Decano/a. El Vicedecano/a será elegido por el mismo período y en la
misma forma que el Decano/a y simultáneamente en la misma Asamblea
de la Facultad.

Artículo 61
Son atribuciones del Decano/a:
a) representar a la Facultad;
b) asistir a las sesiones del Consejo Universitario;
c) informar semestralmente al Consejo Universitario acerca de las labores
de la Facultad e indicar las disposiciones que juzgue necesarias para el
buen funcionamiento de la misma;
d) cumplir y hacer cumplir en su Facultad las disposiciones del Claustro
Mayor, Claustro Menor, del Consejo Universitario, de la Asamblea de
Facultad y del Consejo Directivo;
e) nombrar los Jurados Examinadores en su Facultad, siguiendo para ello
las recomendaciones de los Directores de Escuelas e Institutos correspondientes;
f) supervisar las actividades docentes y administrativas de su Facultad;
g) informar mensualmente al Consejo Universitario acerca de la inasistencia de los profesores a clases, asambleas, Consejos Directivos de
Facultad y exámenes, así como de los motivos de las mismas;
h) presidir las sesiones de la Asamblea y del Consejo Directivo de la Facultad;
i) presidir de oficio las deliberaciones de cualquier organismo dependiente de la Facultad;

j) comunicar al Consejo Universitario las decisiones de la Asamblea y del
Consejo Directivo de la Facultad;
k) informar al Consejo Universitario acerca de las solicitudes de colaciones, equivalencias, convalidaciones y reválidas de estudios y títulos
académicos elevadas a la Facultad; y
l) cumplir con los demás deberes que le asignen el Consejo o el/la Rector/a.

Artículo 62
Para el desempeño de sus labores, el Decano/a estará dedicado de manera exclusiva al servicio de la Facultad, incluyendo las horas de docencia
que establezca el reglamento correspondiente.

Artículo 63
Habrá un Director/a por cada Escuela. Para ser Director/a de una Escuela es indispensable ser dominicano, mayor de edad, estar en pleno
ejercicio de los derechos civiles y políticos, ser profesor en servicio
activo, haber desempeñado en la Facultad, por el período que indiquen
los reglamentos, alguna de las siguientes funciones: Coordinador/a de
Cátedra o Director/a de la Oficina de Planificación Sectorial (OPLASE)
o Encargado/a de Posgrado o Director de Investigación o Director/a
de algún Instituto, habiendo llegado a ella por elección o por concurso, y cumplir, además, con los requisitos mínimos siguientes: tener al
menos el grado de maestría o su equivalente y tener un minimo de 7
años en la Carrera Académica.
Párrafo I.- Los Directores de Escuela serán elegidos exclusivamente por
la asamblea de la Escuela.
Parrafo II.- La composición de la asamblea eleccionaria para elegir directores de escuelas se regirá por lo establecido en el párrafo III del
artículo 26 del el Estatuto Orgánico.

Párrafo III.- El/la Director/a de Escuela desempeñará sus labores bajo
un régimen de contratación de dedicación exclusiva, incluyendo las horas
de docencia que establezca el reglamento correspondiente.
Transitorio.- Los nuevos requisitos aprobados por el Claustro Mayor
en las sesiones del 2012, relativos a la elección del Director/a de Escuela
entrarán en vigencia en las elecciones que siguen a las de 2014.

CAPÍTULO XII
Del Personal Académico

Artículo 64
La enseñanza, la investigación y la orientación de los estudiantes estarán
encomendadas a los miembros del personal docente e investigador.

Artículo 65
El ingreso, permanencia, desarrollo, retiro o salida del personal académico de la Universidad estará regido por un Sistema de Carrera Académica,
en el grado y el posgrado, concebido como un conjunto de derechos,
deberes, prohibiciones, normas y procedimientos reguladores de las relaciones de trabajo y conducta entre la UASD y su personal académico.
Párrafo: Al Reglamento de Carrera Académica se adicionará un manual
que establezca las categorías, funciones y procedimientos, así como la
tabla salarial y de incentivos económicos adicionales.

Artículo 66
La actividad académica de la Universidad se realiza a través del personal
académico, clasificado de la siguiente manera:
a) docente y auxiliares de Carrera en el Grado y el Posgrado;
b) investigadores y auxiliares de Investigación;
c) extensionistas y auxiliares de Extensión; y
d) docente e interinos en el Grado.

Artículo 67
El personal académico descrito en los literales a, b y c del artículo anterior tiene a su cargo los servicios ordinarios de docencia, investigación y
extensión a través de las unidades académicas.

Artículo 68
El personal auxiliar de carrera se clasifica de la siguiente
manera:
a) Monitor/a;
b) Profesor/a Ayudante;
c) Auxiliar de Investigación; y
d) Auxiliar de Extensión.
Párrafo I.- Es Auxiliar de Carrera aquel que, habiendo ingresado de
acuerdo con los reglamentos vigentes, haya sido evaluado con resultados positivos durante tres semestres consecutivos, de conformidad con
dichos reglamentos.
Párrafo II.- La permanencia del Auxiliar en la carrera dependerá de los
resultados de las evaluaciones periódicas que establecen los reglamentos
vigentes.
Párrafo III.- La Carrera Docente se inicia con el/la monitor/a de carrera.
Para Profesor/a Ayudante se ingresará mediante concurso de oposición y
cuando concurran aspirantes que hayan sido Monitores de Carrera se le
otorgará un valor a la labor realizada como tales.
Párrafo IV.- Los Profesores Ayudantes concursarán para pasar a Profesores Interinos, y se le otorgará un valor a la labor realizada como
Ayudantes.

Artículo 69
El personal de la Carrera Académica se clasifica en las
siguientes categorías:
a) Profesor Adscrito;
b) Profesor Adjunto; y
c) Profesor Titular.

Artículo 70
La Carrera Académica (docente, investigadora y extensionista), se inicia
con la categoría de Adscrito, quien ingresará a la Universidad mediante
concurso de oposición, interno o externo.
Párrafo I.- Los Profesores Adscritos impartirán enseñanza teórica y
práctica; participarán en la coordinación y supervisión de la docencia;
ofrecerán tutoría en las asignaturas de la cátedra a que pertenezcan y
podrán participar en proyectos de investigación y de extensión.
Párrafo II.- Los Profesores Adscritos serán evaluados una vez al año
y la permanencia en sus funciones académicas dependerá de los resultados de esa evaluación. Dichas evaluaciones serán realizadas por los
Subconsejos Directivos de Escuela y los Consejos Directivos de Facultad, y
la Dirección de Personal Académico, en coordinación con la Cátedra. Los
resultados se remitirán al Consejo Universitario para que los profesores
sean separados o mantenidos en sus cargos.

Artículo 71
El Profesor Adscrito, con por lo menos cinco años en esa categoría, podrá
alcanzar la categoría de Adjunto a través de un concurso de oposición o
por evaluación que reconozca el mérito a su labor, realizado por el Consejo Directivo de la Facultad, en coordinación con la Dirección de Personal
Académico, conforme a la reglamentación preparada al efecto. El Consejo
Universitario tomará la decisión final sobre cada caso.

Artículo 72
La labor del Profesor Adjunto deberá ser evaluada cada dos (2) años
por el Consejo Directivo de la Facultad, en coordinación con la Dirección de Personal Académico. Para tal fin, el coordinador/a de la
catedra correspondiente asistirá anualmente a un mínimo de tres clases de las que deba impartir el profesor, y levantará acta de asistencia. Asimismo, el Consejo Directivo correspondiente, recabará la más
amplia información sobre el nivel académico del profesor, sin tener
que indicar las fuentes de las informaciones, si están debidamente
justificadas, y recomendar al Consejo Universitario su remoción, con
expediente formalizado para el caso, cuando se compruebe que no
posee las aptitudes necesarias para la docencia.

Artículo 73
El Profesor Titular es el que ostenta la más alta categoría en la enseñanza
de su disciplina en la Universidad.

Artículo 74
La categoría de Profesor Titular se alcanza de la siguiente
manera:
Cuando, siendo Profesor Adjunto, con no menos de diez años en esa
categoría, el Consejo Directivo correspondiente, mediante expediente
elaborado para el caso o por concurso, determine que sus méritos
son tan relevantes, tomando en cuenta: antigüedad, aportes a la docencia, formación académica, investigaciones, compromiso institucional y conducta ética que merece ser promovido a la categoría de Titular. El Consejo Universitario deberá sancionar, por voto mayoritario,
la recomendación que en ese sentido reciba del Consejo Directivo de
la Facultad.

Párrafo: Un reglamento del Consejo Universitario establecerá la normativa para la aplicación de este artículo.

Artículo 75
El Profesor Titular debe realizar reuniones periódicas con los Adjuntos y
Adscritos de la misma asignatura, a fin de conocer la marcha de los programas que enseñan. Deberá, asimismo, exponer ante el Consejo Directivo de la
Facultad correspondiente todos los asuntos concernientes a su asignatura.

Artículo 76
El Profesor Titular deberá probar ante el Consejo Directivo, cada dos
años, que sus programas y prácticas de enseñanza, al igual que su labor
de investigación científica, avanzan conforme al progreso de la ciencia,
mediante un recuento de su trabajo académico sobre los asuntos de la
asignatura que enseña.
Párrafo.- Cuando, a juicio del Consejo Directivo, dicho Profesor Titular no
haya demostrado que sus programas y prácticas de enseñanza están a la
altura alcanzada por la ciencia, este organismo recomendará al Consejo
Universitario, mediante expediente formalizado, que declare vacante el
puesto de Profesor Titular en la asignatura.

Artículo 77
En caso de ausencia o de incapacidad temporal del Profesor Titular, un
Profesor Adjunto lo suplirá en la asignatura.

Artículo 78
Cuando el número de alumnos en una asignatura sea tan grande que
obligue a la creación de diversos grupos en diferentes tandas de clases,
el Consejo Directivo de la Facultad correspondiente podrá atribuir algunas
horas de docencia a los Profesores Adjuntos de esa asignatura.

Artículo 79
Las diferentes categorías del profesorado tendrán validez individual para
cada asignatura. Un/a mismo/a profesor/a podrá pertenecer a diversas
categorías.

Artículo 80
El Profesor Meritísimo es aquel Profesor Titular que, además de sobresalir
en la docencia, la investigación y la creación profesional, realiza una obra
ejemplar, dentro y fuera de la Universidad, en beneficio del progreso universitario y de la cultura nacional. La designación de Profesor Meritísimo
está sujeta a la disposición contenida en el literal i) del Artículo 34 del
presente Estatuto.

Artículo 81
La Universidad establecerá un Sistema de Contratación del Personal de
Carrera Académica (docente, investigador, extensionista), de grado, basado en las siguientes modalidades: contratación exclusiva, contratación a
tiempo completo, contratación a medio tiempo y contratación parcial o por
horas. El sistema se sustenta en la estabilidad del ingreso y en la dedicación cada vez más exclusiva al servicio de la Universidad, cuyos compromisos específicos estarán contenidos en el reglamento correspondiente.
Párrafo: La Universidad contratará para el nivel de posgrado el personal
especializado necesario, según se establezca en los reglamentos para
estos fines.

Artículo 82
Para el ingreso, promoción, premiación y otorgamiento de incentivos dentro de la Carrera Académica se tomarán en cuenta los criterios siguientes:

a) grados académicos alcanzados;
b) producción intelectual;
c) conducta moral y disciplinaria;
d) compromiso, dedicación y cumplimiento de sus deberes con la
Institución; y
e) en igualdad de condiciones, se tomará en cuenta el tiempo en servicio.

Artículo 83
Las promociones de categorías académicas serán ejecutadas de forma
automática al término del cumplimiento de los requisitos de tiempo de
permanencia en el servicio activo y los resultados favorables de la Evaluación Anual del Desempeño del Personal Académico, estableciéndose
un sistema de reconocimiento de méritos alcanzados, con la consecuente
aplicación de un programa de incentivos académicos y económicos diferenciados.

Artículo 84
Se instituye la Comisión de Apelación del Personal Académico, la cual deberá ser integrada y reglamentada por el Consejo Universitario para que,
de manera explícita, quede establecida la facultad de los profesores de
ejercer el derecho a la legítima defensa en caso de que, durante el curso
de una evaluación, éstos se consideren injustamente afectados por informaciones, opiniones o acusaciones que carezcan de fundamento.

Artículo 85
Además de los profesores de la Carrera Académica podrá haber tres (3)
clases de profesores:
a) Profesor Interino;
b) Profesor Especial; y
c) Profesor Invitado.

Artículo 86
El Profesor Interino es aquel que aún habiendo ingresado por concurso
de oposición, debe agotar un período de prueba no inferior a dos (2)
años, tras el cual podrá ser promovido a la Carrera Académica, sujeto a
los resultados de la evaluación de su desempeño.
Párrafo.- La contratación de los Profesores Interinos se hará con la finalidad de cubrir vacantes del cuerpo docente cuando no se hayan podido
llenar con el personal activo de la Universidad.

Artículo 87
El Profesor Especial es aquel profesor/a o investigador/a extranjero/a de una
universidad o institución reconocida contratado por la Universidad Autónoma
de Santo Domingo por un período máximo de un año. El contrato del Profesor Especial sólo podrá ser renovado cuando, después de haber sometido la
asignatura a un concurso de oposición, ningún candidato la hubiese obtenido.
Párrafo.- El Profesor Especial no podrá desempeñar puestos electivos
en la Universidad. Sin embargo, podrá ser invitado a las sesiones de los
organismos de gobierno solo con voz.

Artículo 88
El Profesor Invitado es aquel nacional o extranjero/a que, por su relevante labor, sea contratado para dictar conferencias, cursillos o cursos en
la Universidad. Los Profesores Invitados no tendrán participación en los
organismos de gobierno de la Universidad.

Artículo 89
Habrá, además, los títulos de Profesor Jubilado y de Profesor Honorario. Los Jubilados son aquellos profesores de carrera que por su
edad, tiempo de docencia o por incapacidad física permanente, sean

declarados en retiro con una pensión vitalicia. Los Honorarios serán
las personalidades que, por los méritos reconocidos, puedan honrar
el cuerpo profesoral de la Universidad, con el otorgamiento de ese
título.

Artículo 90
Salvo los Invitados, Jubilados y Honorarios, los demás profesores tendrán la obligación de rendir servicio docente durante el número de horas
que correspondan a la asignatura que enseñan, y un tiempo equivalente
a la mitad de esas horas para entrevistas con sus alumnos, consultas
especiales, presenciales o virtuales, seminarios, trabajos de biblioteca,
corrección de pruebas y cualquier otra actividad que les encomiende el
Consejo Directivo de su Facultad, validadas y remuneradas de acuerdo
con el reglamento correspondiente.
Párrafo: En ningún caso se podrá encomendar a un/a profesor/a la enseñanza oral por más de quince créditos a la semana o su equivalente
cuando se trate de enseñanza práctica.
Transitorio: La disposición anterior no afectará los ingresos producto
de los contratos actuales, los cuales se adaptarán al nuevo sistema de
contratación previsto en el artículo 81.

Artículo 91
Todas las asignaturas vacantes y las de nueva creación se cubrirán mediante concurso de oposición, de acuerdo con el reglamento dictado por
el Consejo Universitario. Ese reglamento estará sujeto a las condiciones
siguientes:
a) se exigirá a quienes deseen participar en concursos de oposición para
cualquier categoría docente, título universitario mínimo de maestría o
su equivalente en el área o en un área afín;

b) todos los que deseen participar en concursos de oposición tendrán
que someter a la consideración del jurado los títulos, obras, casos,
artículos, honores y demás evidencias que comprueben su idoneidad;
c) el concursante deberá someterse a pruebas de exposición escrita y
oral en uno o más temas del programa vigente de la asignatura, escogido por el jurado;
d) el concursante deberá dar una demostración práctica de eficiencia docente ante un grupo que curse la asignatura, exponiendo un tema que
será sorteado dos horas antes de iniciarse esta prueba;
e) si la asignatura requiere demostraciones prácticas, el concursante deberá, ante un grupo que la curse, probar su capacidad para llevar a
cabo las mismas;
f) las convocatorias para los concursos de oposición serán publicadas en un
diario de circulación nacional dos meses antes de la fecha en que deberán
presentarse los concursantes ante el jurado calificador. Una semana antes
de las pruebas orales se invitará al público para que concurra a escuchar a
los candidatos en la sustentación de su derecho a cátedra y en el desarrollo
de los temas y preguntas que el jurado determine;
g) dos semanas antes del día en que deba iniciarse las pruebas para una
asignatura, se expondrá, en sitio público de los Institutos y Escuelas
de la Facultad concerniente, los datos biográficos y académicos de los
concursantes y los programas que piensen desarrollar;
h) terminadas las pruebas del concurso de oposición, el jurado deberá decidir, en una sesión ininterrumpida, acerca de la designación de
la persona a quien ha de otorgarse la asignatura; acerca de quiénes
mostraron suficiente aptitud para la docencia y por qué, aunque no
obtuvieron la asignatura; acerca de quiénes no mostraron suficiente
aptitud para la docencia universitaria y por qué; acerca de, en el caso
que así fuese, por qué a su juicio, la asignatura debe declararse desierta e invitar a la Universidad a que contrate un profesor especial;

i) los jurados deben estar formados por especialistas, y su decisión será
categórica; y
j) las personas que no hayan sido aprobadas en el concurso de oposición,
no podrán pretender su ingreso a la docencia universitaria, en la asignatura, sino dos años después de su rechazo.

Artículo 92
Los concursos de oposición serán regidos por un reglamento único para
toda la Universidad, especificando las particularidades propias que requieran determinadas áreas de evaluación de las Facultades. El depósito de
solicitudes de participación y de credenciales se realizará en la Oficina de
Personal Académico, la cual tiene la responsabilidad de velar por el cumplimiento de los requisitos de presentación de documentos y tramitar los
mismos a las Facultades correspondientes, para la realización del concurso.
Párrafo.- A quienes deseen participar en un concurso de oposición, para
cualquier categoría docente, no auxiliar, les será exigido título universitario
mínimo de maestría o su equivalente en el área o en un área afín.

Artículo 93
Los profesores en servicio activo perderán su docencia cuando incurran
en más de un 10% de ausencias en una de las asignaturas de un curso
del año lectivo, sin tomar en cuenta las licencias y excusas reglamentarias.

Artículo 94
Los profesores en servicio activo perderán su derecho en la asignatura
cuando no entreguen las calificaciones en los primeros 30 días después de
haber finalizado el semestre. En ningún caso, un/a profesor/a que no haya
entregado las calificaciones del semestre inmediatamente anterior, podrá iniciar nuevas labores docentes en el semestre siguiente. Un reglamento normará los casos de los académicos que no cumplan con sus compromisos.

Artículo 95
Los permisos a los profesores para dejar de impartir docencia a cátedras
se regirán por las siguientes normas:
a) cuando el profesor lo solicite para desempeñar otro cargo en las labores universitarias, podrán concederse por todo el tiempo que duren
dichas labores;
b) cuando sean solicitados en razón de tener que ocupar un cargo en
cualquiera de los poderes del Estado, o de sus instituciones autónomas,
podrán concederse hasta por cinco años;
c) cuando vaya a realizar estudios de postgrado becado o avalado por la
Universidad, por el tiempo que duren los referidos estudios, de acuerdo
a las condiciones de estos permisos que establezcan los reglamentos; y
d) cuando sean solicitados por otro motivo podrán concederse hasta por
dos años.

Artículo 96
Al profesor que sin excusa justificada falte a las sesiones del Claustro
Mayor, Claustro Menor, las Asambleas de Facultades, los Consejos Directivos de Facultades o a los actos académicos solemnes, se le descontará el
5% del sueldo correspondiente a un mes por cada ausencia.

CAPÍTULO XIII
De los Estudiantes

Artículo 97
Para inscribirse en la Universidad se requiere estar investido con el título
de bachiller u otro equivalente, expedido o convalidado por el Consejo
Nacional de Educación, y llenar los demás requisitos que exijan los reglamentos universitarios.
Párrafo I.- Para la inscripción en ciertas escuelas o secciones que, por la
especialidad de sus enseñanzas así lo requieran, el Consejo Universitario
podrá fijar, previo informe del Consejo Directivo de la Facultad correspondiente, normas de admisión diferentes a las señaladas.
Párrafo II.- En el caso de personas que quieran ingresar a la Universidad y posean títulos extranjeros o sus equivalentes, el Consejo Nacional
de Educación hará la convalidación en cada caso separadamente y rendirá un informe a la Universidad. Esta se reserva el derecho de aceptar o
no la convalidación.

Artículo 98
Para inscribirse en las distintas escuelas, el interesado deberá acogerse
a los requisitos de ingreso establecidos por el Consejo Universitario, en
atención a las recomendaciones de las Asambleas y Consejos Directivos
de Facultad, Dirección de Orientación Profesional y Dirección de Admisiones.

Artículo 99
La matrícula en la Universidad será ordinaria o por asignaturas. La matrícula ordinaria se concederá a los alumnos que sigan cursos universitarios
acordados en los planes generales vigentes de cada Facultad. La matrícula por asignatura se concederá a los alumnos que sigan una carrera o
cursos interdisciplinarios o no quieran acogerse a la matrícula ordinaria.
Párrafo.- Los Consejos Directivos de Facultad y la Dirección de Coordinación Académica reglamentarán lo referente a este tipo de matrícula, y
establecerán los mínimos y máximos de asignaturas en que un estudiante
se puede matricular.

Artículo 100
En adición a otros derechos fundamentales consagrados en la Constitución de la República, los estudiantes disfrutan de los siguientes derechos:
a) derecho de asociación;
b) elegir y ser elegidos;
c)derecho a su integridad física y moral;
d) estar representados en los organismos de Gobierno de la Universidad;
e) presentar acusaciones y defensas ante los organismos de cogobierno; y
f) Otros contenidos en los reglamentos.

Artículo 101
Son deberes de los estudiantes:
a) asistir puntualmente a las clases, prácticas, pruebas o exámenes que
les correspondan y a todas las actividades universitarias establecidas
como obligatorias;
b) acatar y cumplir las leyes, estatutos, reglamentos, disposiciones y
acuerdos de las autoridades y organismos universitarios;

c) observar una conducta digna, dentro y fuera de la Universidad, de
acuerdo con su condición de estudiantes universitarios y ciudadanos representativos de la más alta casa de cultura nacional;
d) cooperar con las actividades culturales, sociales, patrióticas, deportivas, recreativas y de otra naturaleza, organizadas o apoyadas por la
Universidad;
e) contribuir a la conservación de los edificios, mobiliario, equipos, material de trabajo, jardines y otras pertenencias de la Universidad, así como
a la de su patrimonio espiritual;
f) votar en las elecciones de los delegados estudiantiles, en los organismos universitarios y en las del máximo organismo estudiantil;
g) abstenerse de realizar, dentro del recinto universitario, actividades de
propaganda o proselitismo partidista; y
h) otros deberes que establezca el Código de Ética y los reglamentos.

Artículo 102
El incumplimiento de estos deberes será sancionado de las maneras siguientes:
a) amonestación privada;
b) reenvío de examen;
c) pérdida de derecho a examen;
d) suspensión temporal de su inscripción; y
e) expulsión de la Universidad.

Artículo 103
Las sanciones a los estudiantes por incumplimiento de sus deberes, al tenor
de lo dispuesto en el literal (n) del artículo 56, serán impuestas por los Consejos Directivos de Facultad, en primera instancia, y por el Consejo Universitario, en instancia de apelación, de acuerdo con los reglamentos vigentes.

CAPÍTULO XIV
De la Representación Estudiantil

Artículo 104
Los estudiantes mediante sus representantes elegidos cada dos años,
tendrán derecho a voz y voto en el Claustro Mayor, el Claustro Menor, el
Consejo Universitario, las Asambleas de Facultad, los Consejos Directivos
de Facultad, y en cualquier otro organismo de cogobierno.

Artículo 105
La representación estudiantil será igual a un 33.33% del total de los
miembros del Claustro Mayor, del Claustro Menor, del Consejo Universitario, las Asambleas y Consejos Directivos de Facultad y cualquier otro
organismo de cogobierno.
Párrafo: Cuando los organismos de cogobierno sean convocados con la
finalidad de elegir autoridades, la representación estudiantil será igual al
5% del total de los profesores.

Artículo 106
Los representantes estudiantiles que participen en los organismos
de cogobierno deberán reunir las siguentes condiciones: 1. Estar oficialmente inscritos en la universidad. 2. No ser alumnos repitientes.
3. Tener aprobado por lo menos el 30% de los créditos de sus respectivas carreras. 4. Tener un índice académico acumulado de 80
puntos o más.

Artículo 107
La elección de los representantes de los estudiantes ante el Claustro Mayor, Claustro Menor, el Consejo Universitario, las Asambleas de Facultad,
los Consejos Directivos de Facultad y cualquier otro organismo de cogobierno, deberá efectuarse cada dos años durante los tres meses después
de iniciado el semestre dentro del cual llega a término el mandato.
Párrafo.- Todo estudiante miembro de un organismo de cogobierno concluye el período para el cual fue electo al graduarse o cuando reciba una
remuneración por un cargo administrativo en la Universidad, exceptuando
la labor de monitor y estudiantes con becas. En estos casos el representante será reemplazado por la agrupación que lo postuló en un plazo no
mayor de tres meses.
Transitorio.- Los requisitos del párrafo anterior tendrán vigencia a partir de las elecciones estudiantiles siguientes a las celebradas el 30 de
septiembre de 2011.

Artículo 108
Un reglamento dictado por el Consejo Universitario dispondrá lo que este
Estatuto no contemple en relación con la representación de los estudiantes y forma de elección de los delegados.

CAPÍTULO XV
Del Personal Administrativo

Artículo 109
La Universidad tendrá los servidores administrativos que requiera la buena marcha de sus actividades. Para tal fin, un reglamento regirá la selección de un personal eficiente y honesto.

Artículo 110
El Reglamento de la Carrera Administrativa en la Universidad, garantiza al
servidor su estabilidad y promoción gradual dentro de un escalafón que
tiene en cuenta la capacidad, la buena conducta y los años de servicio. La
Carrera Administrativa culmina en el cargo de Vicesecretario/a General.

CAPÍTULO XVI
De los bienes e ingresos de la Universidad

Artículo 111
Son propiedad de la Universidad todos los bienes de cualquier naturaleza
que figuren en la actualidad dentro de su patrimonio o que formen parte
de éste en el futuro.

Artículo 112
Las fuentes de ingreso de la Universidad son las siguientes:
a) los provenientes del 5% del presupuesto público aprobado en las Leyes
5778 y 139-01, y cualquier fondo que a otro título reciba del Estado y sus
instituciones, de los particulares o de organismos extranjeros y nacionales;
b) el producto de los derechos de autor y de patentes;
c) del aporte de los estudiantes y egresados por servicios y derechos
académicos;
d) de los frutos civiles o naturales de los bienes muebles, corporales o
incorporales o bienes inmuebles que formen parte de su patrimonio;
e) de las utilidades que generen las empresas que formen parte de su
patrimonio;
f) la venta de bienes y servicios que realice la Universidad;
g) de los beneficios del Fondo Patrimonial creado con donaciones y
aportaciones; y

h) cualesquiera otros ingresos de origen lícito que reciba la Universidad.

Artículo 113
La Universidad constituirá empresas de acuerdo a la ley, con administración separada de su estructura administrativa, con la finalidad de generar
recursos financieros adicionales a los que reciba del Estado para cumplir
su misión.
Párrafo.- El personal de estas empresas se regirá por el Derecho laboral dominicano y no pertenecerá a la Carrera Administrativa de la Universidad.
Transitorio.- El personal de Carrera Administrativa que trabaja actualmente en las empresas universitarias y que no permanezca en ellas se
les reconocerán sus derechos.

Artículo 114
Los bienes de la Universidad, cual que sea su naturaleza, no podrán ser
enajenados, ni su propiedad desmembrada, ni gravados con ninguna
suerte de derechos reales, ni arrendados ni alquilados por más de dos
años, sin autorización previa del Claustro Mayor. Estos bienes serán identificados, ubicados físicamente y se harán de conocimiento público.

Artículo 115
Un Plan Maestro aprobado por el Consejo Universitario, regula el uso
urbano y de edificaciones del campo universitario, por constituir la Ciudad
Universitaria un Patrimonio Monumental de Arquitectura Moderna, con
vocación de Patrimonio de la Humanidad.
Párrafo.- El uso urbano y de las edificaciones de cada Recinto, Centro y
Subcentro será regulado por sus respectivos Planes Maestros.

CAPÍTULO XVII
DEL FUERO UNIVERSITARIO

Artículo 116
Los recintos y muebles de la Universidad, a cualquier título que sea y cualesquiera que sean los fines a que se dediquen, son inviolables. Su vigilancia y el mantenimiento del orden dentro de ellos son de la competencia
y responsabilidad de las autoridades universitarias. Ninguna autoridad
pública podrá penetrar en dichos recintos, ni acceder a dichos muebles,
sin la autorización del Consejo Universitario o del/la Rector/a.

Artículo 117
Todas las edificaciones, terrenos, fincas, vías y, en general, bienes inmuebles, con sus anexidades y dependencias, así como los lugares, de
su propiedad o no, en los cuales se realicen, de modo permanente u
ocasional, actividades docentes, de investigación, administrativas, culturales, recreativas o de cualquier otro carácter, y las residencias de profesores, investigadores, estudiantes y empleados que sean propiedad o
estén arrendados o usufructuados de cualquier forma destinados por la
Universidad a esos fines, son inviolables, no solo por los particulares sino
también y, de manera principal, por las autoridades públicas nacionales,
provinciales, municipales o de otra clase, cualquiera que sea la fuente
donde se originen sus poderes, facultades, atribuciones o derechos. Dichas autoridades no podrán penetrar en ellos, ni realizar su allanamiento,
a menos que sean requeridas por el Consejo Universitario o el/la Rector/a.
La conservación del orden en los lugares antes indicados, cuya enunciación no es limitativa, corresponde única y exclusivamente a las autoridades universitarias.

CAPÍTULO XVIII
De los Signos y Símbolos de la
Universidad

Artículo 118
La imagen que identifica a la Universidad como institución está constituida
por el conjunto de signos y símbolos que comunican su esencia, por los
que es reconocida a nivel nacional y mundial y que constituyen parte de
su patrimonio cultural.

Artículo 119
El emblema de la Universidad Autónoma de Santo Domingo está representado por un óvalo dividido en tres partes:
a) la parte superior izquierda contiene una imagen que simboliza el águila
imperial bicéfala de la familia Habsburgo;
b) en la parte superior derecha, se encuentra la Cátedra de Santo Tomás
de Aquino, discípulo de Santo Domingo de Guzmán, fundador de la
Orden de los Dominicos;
c) en la parte inferior y mitad del óvalo, aparece un galgo que sostiene
una tea entre sus fauces e incendia el globo terráqueo, que simboliza
la fogosa oratoria de la Orden de los Predicadores; y
d) sobre éstos, se encuentra una estrella que simboliza una marca de
nacimiento que tenía Santo Domingo en la frente y dos ramas entrecruzadas: una de laurel y la otra de palma, que representan el triunfo de
la Orden de los Predicadores.

Párrafo: Se unifica el uso del emblema en todos los Recintos, Centros y
Subcentros universitarios, en todas las Facultades y demás dependencias.
No puede utilizarse en los asuntos oficiales ningún otro que le sea contrario, sea por rediseño o por distorsión.

Artículo 120
Los colores oficiales que representan a la academia son: el azul añil (azul
reflejo) y el blanco. El color azul añil (azul reflejo), significa la estabilidad,
la libertad, la dignidad y la ciencia, que corresponden a los conceptos y
principios de la academia. El color blanco, color del comienzo, del nacimiento, la pureza y la verdad, como cuna del conocimiento y faro de la
verdad científica que simboliza la Universidad.
Párrafo.- Se mantendrán como única identidad institucional y se utilizarán como colores oficiales el azul añil (azul reflejo) y el blanco.
No se usarán tonalidades en ninguna de sus variantes, salvo casos
consignados en el reglamento que normará el uso de los signos de
identidad institucional.

Artículo 121
La bandera está conformada por un rectángulo en forma horizontal con
las mismas dimensiones de la Bandera Nacional, dividido su espacio en
dos franjas también horizontales. La franja superior es de color azul añil
(azul reflejo) y la inferior, es de color blanco. En el centro de la bandera y
manteniendo las mismas medidas en las partes superior, inferior y laterales, va colocado el emblema, bordeando la parte superior del óvalo con
una línea blanca que lo diferencia del fondo azul reflejo en ese espacio de
la bandera.
Párrafo.- Todos los locales universitarios colocarán la Bandera Universitaria junto a la Bandera Nacional y otras que el protocolo señale, al frente
de las instalaciones y en los actos oficiales.

Artículo 122
El lema de la academia es: Primada de América y será el eje a través del
cual girará toda comunicación institucional y se colocará inmediatamente
debajo del nombre de la Universidad; y más abajo, el dato de su registro
fundacional: Fundada el 28 de octubre de 1538.

Artículo 123
El tipo de letra utilizado será el gótico moderno, preservando la originalidad de la tipografía y el espíritu centenario de la Universidad. Deberá emplearse como logotipo del membrete en todos los documentos oficiales.
Para uso del cuerpo de textos administrativos se utilizará el tipo románico.
Párrafo.- Un reglamento aprobado por el Consejo Universitario especificará las variantes del tipo de letra que se usará en la publicidad institucional.

Artículo 124
El Himno Universitario representa un canto al conocimiento científico, a
la enseñanza, a la educación, a la libertad y a la verdad científica. Debe
entonarse en todas las actividades académicas oficiales, como lo señale
el protocolo oficial.
Párrafo I.- No podrá ser distorsionado, ni transformado, ni hacer adaptaciones desde el punto de vista musical. Todos los coros de los Recintos,
Centros y Subcentros Universitarios y todas las grabaciones que se realicen, deberán respetar las letras, la partitura y el arreglo musical realizados por sus autores.
Párrafo II.- Las letras del Himno Universitario son las que compuso en
1939, Ramón Emilio Jiménez, la música fue aportada por Ramón Díaz, y
su texto es el siguiente:

Centro de vida intelectual
por cuatro siglos consagrado
de noble ciencia manantial
luz del presente y del pasado. (bis)
Eres fanal de nuestra mente,
de la conciencia orientación,
del vasto mundo noble simiente
y de la patria religión. (bis)

Artículo 125
La Cátedra Universitaria es un símbolo que representa la Cátedra de Filosofía de Santo Tomás de Aquino, la cual era utilizada por el Rector en los
actos solemnes que se celebraban en el Aula Magna. Es una reliquia de la
época colonial que fue tallada en caoba en el siglo XVI. Las patas de ese
histórico mueble representan los cuatro evangelistas en la forma siguiente:
a) la que tiene forma de pie de ángel representa a SAN MATEO;
b) la que tiene forma de garra de león, representa a SAN MARCOS;
c) la que tiene forma de pata de buey representa a SAN LUCAS; y
d) la que tiene forma de garra de águila representa a SAN JUAN.

Artículo 126
El Aula Magna es una estructura inspirada en la forma del bohío taíno,
como forma de conservar la cultura aborigen que habitaba la isla al momento de darse el encuentro de las dos culturas el 12 de octubre de
1492. Es un auditorio concebido para realizar actos académicos solemnes, así como actividades que eleven el nivel cultural de la familia universitaria y de la sociedad en general.
Párrafo I.- Fue construida en el 1957 por el arquitecto Humberto Ruiz
Castillo con base en un diseño del arquitecto francés A. Dunoyer de Segonzac.

Párrafo II.- Un reglamento aprobado por el Consejo Universitario regulará el uso que se le dará a ese espacio que representa un símbolo de la
Institución.

Artículo 127
El Alma Máter es una escultura que representa la Madre Nutricia, símbolo
de la fuente del saber, donde abrevan las personas para alimentarse del
conocimiento científico que crea, transmite y divulga la Institución. La autoría de la escultura corresponde al escultor español Benjamín Saúl.

Capítulo XIX
De las elecciones, los derechos
electorales y la Comisión
Central Electoral

Artículo 128
Las elecciones periódicas, reglamentadas, arbitradas con independencia
y organizadas por la misma Institución para elegir sus autoridades, y
por los gremios para elegir sus dirigentes, son una de las expresiones
fundamentales en que se sustenta la autonomía de la Universidad y su
carácter democrático.

Artículo 129
El derecho de elegir y ser elegido/a en las condiciones consignadas en
este Estatuto y los reglamentos no podrá ser impedido ni obstaculizado
por ninguna autoridad administrativa. Tales impedimentos u obstáculos
darán pie a procesos administrativos internos de los afectados en contra
de los responsables.

Artículo 130
Las elecciones de Rector/a, Vicerrectores/as, Decanos/as, Vicedecanos/
as y Directores/as de Escuelas, Directores/as y Subdirectores/as de Centros y Máximos/as Ejecutivos/as de Recintos, se efectuarán de forma simultánea, el tercer miércoles del mes de junio, cada cuatro años, con
boletas únicas para los casos del Rector/a y de los/las Vicerrectores/as,
del Decano/a y el Vicedecano/a, y de los demás candidatos/as, en horario
de 8:00 a.m. a 8:00 p.m.. En caso de que ningún candidato o candidata

obtenga la mayoría absoluta de los votos depositados, se realizará una
nueva elección una semana después de ofrecidos los resultados oficiales,
en la que participarán los dos candidatos/as que obtuvieron más votos,
en cuyo caso saldrá ganadora la persona que obtenga la mayoría simple
de los votos válidos emitidos.
Transitorio: Las autoridades que tomen posesión el 28 de febrero de
2014 estarán en sus puestos hasta la toma de posesión de las autoridades electas en la siguiente elección.

Artículo 131
Los/as funcionarios/as elegidos/as tomarán posesión el 16 de julio, tras
ser confirmada su elección por la Comisión Central Electoral, y ser juramentados ante funcionario competente. Las autoridades electas permanecerán en sus funciones hasta que sus sucesores tomen posesión del
cargo.

Artículo 132
Las vacantes de los puestos electivos que se produzcan por fallecimiento,
renuncia, enfermedad, destitución o por otra causa, serán ocupadas interinamente por un período no mayor de 45 días laborables, con excepción
del/la Rector/a que se regirá por lo dispuesto en el artículo 37, plazo en
que deberá convocarse a elecciones, siempre que el tiempo faltante sea
mayor de un (1) año; si el tiempo es de un año o menos, el organismo a
que pertenece el funcionario hará la designación. La persona que resultare elegida o designada ejercerá el cargo hasta que finalice el período para
el que fue elegida la persona titular a quien sustituye.

Artículo 133
La dirección, administración y supervisión de los procesos de elecciones
de autoridades y de representantes estudiantiles al cogobierno de la Universidad Autónoma de Santo Domingo estarán a cargo de una Comisión
Central Electoral y de Subcomisiones Electorales de Facultades, Recintos
y Centros dependientes de ésta. La Comisión Central Electoral estará inte-

grada por tres (3) miembros, con sus respectivos suplentes, designados
por el Consejo Universitario, entre los profesores de reconocida trayectoria institucional y solvencia moral. El Consejo Universitario nombrará al/la
Presidente/a y al/la Secretario/a.

CAPÍTULO XX
DEL CONTROL Y LA TRANSPARENCIA

Artículo 134
Todo/a funcionario/a de la Universidad está en la obligación de realizar
su labor con transparencia, de acuerdo a las normas que establecen las
leyes, el Estatuto Orgánico y los reglamentos.

Artículo 135
Todos/as los/as funcionarios/as, electos/as o designados/as, que administren recursos financieros harán una declaración jurada de bienes, con
inventario de sus activos y pasivos, a más tardar a los 30 días de la toma
de posesión del cargo y a los 30 días de salir del mismo. El no depósito
de esta declaración conlleva la suspensión automática del sueldo. Estas
declaraciones se depositarán en la Consultoría Jurídica y se publicarán en
la página web de la Universidad, y la del Rector o Rectora, en un periódico
de circulación nacional, por cuenta de la Universidad.

Artículo 136
Todos/as los/as funcionarios/as, electos/as o designados/as, rendirán
cuentas de su labor, a más tardar cada seis meses, y entregarán a los
nuevos funcionarios, el día de la toma de posesión, un informe actualizado de los bienes muebles e inmuebles existentes en el organismo,
de los programas y proyectos en ejecución, y de los compromisos,
internos y externos, pendientes.

CAPÍTULO XXI
Disposiciones Generales

Artículo 137
El Consejo Universitario dictará el reglamento que corresponda a las políticas y al sistema de transversalización del estudio y tratamiento de género en toda la estructura universitaria.

Artículo 138
Todos los pagos que se hagan por concepto de derechos de matrículas,
expediciones de títulos, exámenes de reválida y cualquier otro a que haya
lugar en virtud de la reglamentación vigente o futura, deberán efectuarse
en la Tesorería de la Universidad, mediante autorización expedida por las
autoridades competentes.

Artículo 139
Los cargos electivos de la Universidad son incompatibles con cualquier
empleo o función pública, a excepción del Notariado. La violación de estas
disposiciones implica renuncia de pleno derecho al cargo.

Artículo 140
A los miembros de la Familia Universitaria les asiste el derecho de asociarse, con fines institucionales.

Artículo 141
Los cargos de Dirección Académica y de Dirección Administrativa, se clasifican en:

a) cargos de elección;
b) cargos de concurso; y
c) cargos de libre nombramiento.
Párrafo: El reglamento correspondiente, tomando en cuenta la Ley de la
Función Pública, establecerá los cargos para las dos últimas categorías.

Artículo 142
El Claustro Mayor, mediante Resolución del 27 de septiembre de 2000,
dispuso el reordenamiento ambiental, ético, moral y físico de la Universidad.
Párrafo.- Sólo el Claustro Mayor podrá autorizar el establecimiento de
negocios propiedad de particulares en el campus de la UASD.

Artículo 143
Para inscribirse en los programas de posgrado se requiere, además de
tener el título de licenciado/a o su equivalente, cumplir con los demás
requisitos que establezcan los reglamentos.

Artículo 144
Se establece el procedimiento de la revocación de los funcionarios designados o elegidos que no cumplan con sus funciones. Un reglamento del
Consejo Universitario establecerá dicho procedimiento.

Artículo 145
El Consejo Universitario y el/la Rector/a estarán en la obligación de hacer
cuanto esté a su alcance para que la autonomía universitaria, garantizada
en el artículo 63 de la Constitución de la República del 2010, sea respetada, y de igual modo, la inviolabilidad de los espacios universitarios sea
reconocida en la Constitución y en las leyes.

CAPÍTULO XXII
Disposiciones Transitorias

Artículo 146
El Claustro Mayor en su sesión del 30 de agosto de 2011 decidió: “Aprobar la reapertura del proceso de revisión y reformas del Estatuto Orgánico de la Universidad y que el propio Claustro Mayor lo asuma”.

Aprobado por el Claustro Mayor en sus sesiones del 30 de agosto del 2011, 25 de enero y 8 de febrero del 2012, celebradas en la
Universidad Autónoma de Santo Domingo, Distrito Nacional, República
Dominicana, a los 474 años de la fundación de la Universidad.

Mateo Aquino Febrillet
Rector

 
 
 
Santo Inocencio Mercedes

 

Secretario General

Glosario
Aprobado
por el Consejo Universitario
mediante la Resolución No. 2012-083
del 16 de abril del año 2012

 

Glosario Aprobado

por el Consejo Universitario

A)
1. Acreditación:
Reconocimiento formal que hace una institución facultada para
ello, de que un organismo cumple con los requisitos especificados
y es competente para desarrollar las funciones inherentes a su
naturaleza.

2. Alumno Repitiente:
Es aquel o aquella que no haya aprobado más de la mitad de las asignaturas cursadas en el semestre inmediatamente anterior al de su elección
como representante estudiantil y en los semestres en que ostente dicha
calidad.

3. Año Sabático:
Es un período en el que un/a académico/a, con diez (10) o más años
en servicio ininterrumpido y contratado/a con una carga docente mínima equivalente a medio tiempo, tiene derecho a apartarse de sus
labores universitarias ordinarias a fin de realizar, dentro o fuera del
país, una actividad sistemática en beneficio de su propia superación
intelectual o profesional. Se le llama licencia sabática, y cubre un
período de un (1) año académico o dos (2) semestres académicos
consecutivos con el goce pleno de su remuneración mensual y de sus
otros derechos laborales.

4. Arquitecto:
Titulo de grado que requiere una carga académica superior a la carga
académica requierida para la obtención del titulo de licenciatura.

 

Glosario Aprobado

5. Asamblea:
Reunión de personas a quienes agrupa una comunidad de intereses o
funciones, que ha sido regularmente convocada para deliberar conforme
a las normas establecidas, con el fin de adoptar decisiones.

6. Asignatura:
Es un segmento de conocimientos de una disciplina que es estudiado en
detalles dentro de un plan de estudios de la Universidad.

7. Autonomía universitaria:
La Autonomía comprende la facultad de la Universidad de dictar su propio
Estatuto Orgánico, elegir sus autoridades, crear y aprobar planes y programas de estudios, nombrar sus catedráticos y funcionarios, y disponer
de los recursos financieros obtenidos.

B)
8. Bula in Apostolatus Culmine:
Documento emitido por el Papa Paulo III, el 28 de octubre de 1538,
en respuesta a la petición que le hicieran el Prior y los frailes del
Convento de los Dominicos de la casa de Santo Domingo, que en ese
lugar regentaban desde hacía algunos años la Universidad de Santo
Tomás de Aquino, la cual carecía de los privilegios e indultos apostólicos necesarios para promover a los grados que solían concederse
en las Universidades de estudios generales de los Reinos de España.
Acogiendo la petición de los dominicos, el Papa Paulo III, en la Bula In
Apostolatus Culmine, dispuso erigir y fundar la Universidad de Santo
Domingo, cuyos promovidos a los grados de Bachilleres, de Licenciados, Doctores y Maestros respectivamente, gozarán de todos y cada

por el Consejo Universitario

uno de los privilegios, inmunidades y favores, que poseen, usan y
gozan, los que son promovidos a los mismos grados, en las Universidades de Alcalá, de Salamanca o cualquier otra universidad de los
Reinos de España.

C)
9. Calificación:
Puntuación obtenida por concepto de la evaluación del rendimiento del
estudiante en cada asignatura, realizada por el profesor.

10. Capacitación:
Se refiere al mejoramiento y actualización profesional del personal académico y administrativo, con el propósito de elevar la eficiencia y la calidad
institucional.

11. Carrera académica:
Es la parte de la carrera profesoral que se inicia con la categoría de Profesor Adscrito, en las actividades docentes, de investigación y extensión,
condición indispensable para que un profesor sea considerado en servicio
activo. La carrera académica continúa con la categoría de Profesor Adjunto y culmina con la categoría de Profesor Titular.

12. Carrera Administrativa:
Es el conjunto de principios, derechos, deberes, órganos y condiciones
que norman las relaciones de trabajo de los servidores administrativos
con la Institución, en un marco de profesionalización y dignificación laboral, para dar unidad, estabilidad y coherencia al Sistema de Administración universitaria.

 

Glosario Aprobado

13. Carrera Docente:
Es la parte de la carrera profesoral que se inicia con las funciones de
Monitor de carrera, continúa sucesivamente con las funciones de Profesor Ayudante y de Profesor Interino, el cual puede ingresar a la carrera
académica después de dos años de interinidad y previa evaluación de su
desempeño.

14. Categoría profesoral:
Es la clasificación del personal académico en función del tiempo de trabajo en la institución y del resultado de la evaluación de su desempeño.
Las diferentes categorías del profesorado tendrán validez individual para
cada asignatura. Un/a mismo/a profesor/a podrá pertenecer a diversas
categorías.

15. Categorías de la Carrera Académica
El personal de la Carrera Académica se clasifica en tres categorías:
a) Profesor Adscrito: Constituye la categoría inicial de la Carrera Académica, y para ello debe haber ingresado a la Universidad mediante concurso de oposición, interno o externo.
b) Profesor Adjunto: Constituye la segunda categoría de la Carrera Académica. Se adquiere después de por los menos cinco años en la categoría
de Adscrito, por la participación en un concurso de oposición o por
evaluación del Consejo Directivo de la Facultad, en coordinación con la
Dirección de Personal Académico.
c) Profesor Titular: Constituye la más alta categoría en la enseñanza de
una disciplina en la Universidad. Se adquiere después de por lo menos
diez años en la categoría de Adjunto, por evaluación del Consejo Directivo de la Facultad o por concurso.

por el Consejo Universitario

16. Certificado:
Documento expedido por la Universidad, firmado por la autoridad
competente, como constancia de que su titular asistió a un curso o
actividad extracurricular programado por la institución.

17. Ciclo Básico:
Conjunto de asignaturas de formación básica para todas las carreras,
incluidas en los planes de estudios vigentes, seleccionadas y aprobadas, de manera total o en un determinado porcentaje, antes de
inscribir las asignaturas propias de las carreras.

18. Cogobierno:
Sistema de dirección en el cual, los organismos colegiados de dirección están integrados con representantes de los diferentes sectores
que participan en la vida de una institución. El cogobierno universitario integra a las autoridades, a representantes de profesores y de
estudiantes, y en los niveles más altos de toma de decisiones (Claustro y Consejo Universitario) incluye también a representantes de los
servidores administrativos.

19. Colación:
Es la aprobación mediante examen de una o varias asignaturas de las
establecidas en un plan de estudios, no cursadas por razones ajenas
a la voluntad del estudiante, para completar o cotejar el plan general
de estudios vigente.

20. Consejo Universitario:
Es el organismo de gobierno permanente de la Universidad, conformado por el/la Rector/a, Vicerrectores/as, Secretario/a General, Decanos/as, representantes de Recintos y Centros Universitarios, con

 

Glosario Aprobado

representación de profesores/as, de estudiantes y del personal administrativo, que tiene la responsabilidad de normar, administrar y dar
seguimiento a todas las actividades de la Universidad.

21. Control Administrativo:
Es un componente de la Administración universitaria, llevada a cabo
por todos los niveles directivos, para verificar, con indicadores cuantitativos y cualitativos, el cumplimiento de los objetivos y las diferentes
aplicaciones financieras, de acuerdo a las reglas institucionales.

22. Convalidación:
Es el proceso mediante el cual una Institución de Educación Superior,
aplicando sus propias reglamentaciones y las del Ministerio de Educación Superior, Ciencia y Tecnología, acepta como válidas las asignaturas cursadas y aprobadas por el estudiante en otra institución
de educación superior, con base en la correspondencia entre calidad
y número de créditos y el contenido de las asignaturas a convalidar.

23. Crédito:
Unidad de valor asignado a los cursos en función de su peso académico dentro de un Plan de Estudio. El crédito representa el trabajo
académico en una de las siguientes opciones: a) Una hora de docencia teórica semanal a lo largo de un semestre académico, b) Una
sesión de práctica semanal a lo largo de un semestre académico de
igual duración.

24. Currículo:
Estrategia general elaborada a partir de la visión, misión y valores de
la Universidad, para la aplicación de planes de estudios de carreras
académicas ofertadas por la universidad.

por el Consejo Universitario

D)
25. Dedicación Exclusiva:
Régimen de contratación que obliga al contratado a laborar con carácter
de exclusividad para la institución contratante. En la Universidad Autónoma
de Santo Domingo, todos los funcionarios de cargos electivos deben laborar bajo el régimen de contratación de dedicación exclusiva a la institución.

26. Diploma:
Documento o credencial que expide la Universidad para acreditar un grado académico o distinción académica.

27. Disciplina:
Es una rama del conocimiento o campo de estudio, investigada y enseñada por una escuela, que se ha convenido deslindar de otros campos e
incluso dentro de una misma rama del conocimiento, a los fines de facilitar
la administración académica.

28. Doctorado:
Es el mayor grado académico de posgrado o de cuarto nivel que se podrá
otorgar en la Universidad a partir de la obtención del grado o del título
de Maestro, según los correspondientes programas. Tiene como requisito
final la presentación de una investigación original.

E)
29. Electores:
Son electores en los organismos de cogobierno de la UASD el personal
académico en servicio activo: docentes, investigadores y extensionistas.

 

Glosario Aprobado

Los profesores meritísimos, y los representantes de los profesores ayudantes, de los estudiantes y de los servidores administrativos en las condiciones y proporciones que establece el Estatuto Orgánico.

30. Elegibles:
Son los profesores en servicio activo que cumplen con los requisitos establecidos en el Estatuto Orgánico y en el Reglamento para Elecciones de
Autoridades Universitarias para el cargo a que aspiran.

31. Empresas Universitarias:
Son unidades económicas que crea la Universidad de acuerdo a la ley,
con administración separada de su estructura administrativa, con la
finalidad de generar recursos financieros adicionales a los que recibe
del Estado, para cumplir su misión. El personal de dichas unidades no
pertenece a la carrera administrativa de la UASD, por tanto, se rigen
por el derecho laboral dominicano. En las empresas universitarias, la
Institución no puede comprometer su patrimonio inmobiliario. No caen
en esta categoría las unidades que aunque ofrezcan algún producto o
servicio estan vinculadas indisolublemente a las funciones de docencia, investigación y extensión.

32. Equivalencia:
Es la aceptación, como válida, de una o varias asignaturas ya cursadas en
la UASD, para los fines de una carrera diferente, siempre que el contenido
esencial de los programas sea equivalente.

33. Evaluación de aprendizajes:
Es la valoración que se realiza de los aprendizajes evidenciados por
los alumnos en las asignaturas cursadas en un semestre regular o
intensivo.

por el Consejo Universitario

34. Evaluación institucional:
Es la valoración sobre el desempeño que se realiza a una institución educativa.

35. Extensión Universitaria:
La Universidad participa en la preservación de la herencia social y cultural
de la nación, para enriquecerla, aprovecharla y difundirla, contribuyendo
a la formación del espíritu público. Esta Misión de la Universidad se cumple
mediante la Extensión Universitaria. Se trata de acompañar al pueblo, las
comunidades y organizaciones en sus proyectos de vida y de Nación.

F)
36. Fondo Patrimonial:
Es un instrumento para recabar aportes financieros y capitalizarlos de
manera perpetua, usando sólo los beneficios derivados de las inversiones
contempladas en el reglamento correspondiente, con la finalidad de desarrollar actividades académicas preestablecidas y contribuir a la estabilidad financiera de programas específicos y de toda la Institución.

37. Función Académica de Dirección:
Es aquella que desempeñan los siguientes funcionarios:
a) El Director/a General de Posgrado;
b) El Director/a General de Investigaciones Científicas y Tecnológicas;
c) El Director/a de una Escuela;
d) El Director/a de un Instituto de Investigación;
e) El Director/a de Investigación de Facultad;
f) El Director/a de Posgrado de Facultad;
g) Los Máximos Ejecutivos de Recintos Universitarios;
h) Los Directores y Subdirectores de Centros Universitarios, y
i) Cualquier otra función definida por el Consejo Universitario.

 

Glosario Aprobado

38. Función Académica:
Es la función de docencia, investigación y extensión, que se lleva a
cabo, fundamentalmente, a través de las Vicerrectorías, Facultades,
Recintos, Centros y Subcentros.

G)
39. Grado:
Corresponde a los estudios de tercer nivel con una duración mínima de
ocho semestres académicos, con la finalidad de graduar profesionales de
sólida formación en un área del conocimiento, que conduce a la obtención
de un título de Licenciado, Ingeniero, Arquitecto, Médico, Odontólogo,
Veterinario u otros semejantes, que le otorgue el derecho a ejercer o
tramitar el ejercicio legal de una profesión.

I)
40. Ingeniero:
Titulo de grado que requiere una carga académica superior a la carga
académica requierida para la obtención del titulo de licenciatura.

L)
41. Libertad de Cátedra:
Derecho de opinión y reflexión científica ejercido por el profesor o profesora en el cumplimiento del programa académico aprobado por la Univer-

por el Consejo Universitario

sidad, como consecuencia de la libertad de pensamiento garantizada en
la Constitución de la República y en los pactos y tratados internacionales.

42. Licenciatura:
Título de grado que confiere la Universidad, por medio de las Facultades,
a los estudiantes que concluyen satisfactoriamente el plan de estudios de
una carrera profesional.

M)
43. Maestría:
Curso de posgrado ofrecido por la Universidad, después de haberse obtenido la certificación oficial de que han concluido los estudios de tercer
nivel o de grado. Tiene un mínimo de treinta (30) créditos. Al cumplir
todos los requisitos se obtiene el título de Magister o Maestro/a, en sus
diferentes modalidades (M. A. , M. Sc. , MBA).

44. Matrícula:
Es la inscripción de una persona en una Facultad o Escuela de la Universidad.

45. Mayoría Absoluta:
Es la mayoría que requiere más de la mitad de los votos depositados o
emitidos a favor de un candidato o propuesta para declararlo (a) ganador
(a).

46. Mayoría Simple:
Es la mayoría más grande, cuando ningún candidato/a o ninguna propuesta alcanza la mayoría absoluta. La mayoría simple la obtiene el candidato, candidata o propuesta que obtiene más votos.

 

Glosario Aprobado

47. Memoria:
Relación de hechos, datos y proyectos que dan cuenta de las ejecutorias
realizadas en un determinado período, que rinde de manera periódica un
incumbente u organismo de la Universidad.

N)
48. Nivel Técnico Superior:
Estudios universitarios de nivel de pregrado, con una duración de entre
cuatro y seis semestres, como salida lateral dentro de los estudios de
grado o independientes de estos.

O)
49. Organismos:
Estructuras del Gobierno Universitario que tienen por misión aplicar
las funciones de la Universidad, trazar las políticas y adoptar decisiones que convengan para los fines de la institución. Estos organismos
son de 2 categorías: Colegiados y Unipersonales, contenidos en el
Estatuto Orgánico y en los Reglamentos aprobados por el Consejo
Universitario.

50. Orientación Profesional:
Es el conjunto de procedimientos y de métodos que, en función de las
características individuales y de las necesidades económicas y sociales,
permite determinar las posibilidades del mayor rendimiento en el trabajo
del sujeto de la educación.

por el Consejo Universitario

P)
51. Personal Académico:
Se refiere al personal docente, de investigación y de extensión de la Universidad.

52. Políticas:
Comprende las directivas generales que han de orientar la acción educativa,
los objetivos derivados y el orden de prioridades, en cuanto a los fines que
debe cumplir la educación como institución social, inspirada en el sistema de
valores de la sociedad. Al nivel más general contienen principalmente: a) Una
formulación de los fines y objetivos de la educación que refleja la filosofía y la
política educativa del Estado; b) Un Plan de Estudio; c) Un conjunto de programas o cursos de estudio; y d) Instrucciones o guías metodológicas generales
o específicas para los maestros y maestras.

53. Posgrado:
Corresponde a los estudios de cuarto nivel, que tienen como requisito
haber obtenido un título de grado, con el objetivo de preparar recursos
humanos para la docencia, la investigación y el trabajo especializado.

54. Profesor en Servicio Activo:
Es el profesor que pertenece a la Carrera Académica por haber alcanzado
la categoría de Adscrito, y realiza una función académica. Los profesores
en proceso de jubilación que no imparten docencia, así como los profesores jubilados recontratados, no son profesores en servicio activo.

55. Propiedad Intelectual:
Derecho particular a favor de la Universidad, de un autor u otros titulares
de derechos, sobre las obras originales del intelecto humano, en sus diferentes expresiones y usos.

 

Glosario Aprobado

R)
56. Reelección:
Una segunda elección en el mismo cargo, inmediatamente después de la
primera elección. Entendida de esta manera, la reelección está prohibida
por el Estatuto Orgánico de la UASD para todos los cargos electivos.

57. Reglamento:
Declaración explícita que define la práctica y el procedimiento que ha de
seguirse en la acción individual y colectiva dentro de una organización.

58. Rendición de cuentas:
Es la presentación y publicación de un informe escrito sobre la gestión
realizada por un funcionario, organismo o institución pública, a partir de
los planes, proyectos y compromisos contraídos, con la finalidad de facilitar el control de la gestión pública por parte de los ciudadanos y ciudadanas.

59. Reválida:
Es la equivalencia de un título profesional o grado académico otorgado
por una universidad o instituto de educación superior extranjero legalmente establecido, con el respectivo título profesional concedido por la
Universidad, previa aprobación de los requisitos establecidos.

60. Revocación:
Es el derecho de una determinada proporción de electores, a partir de la
inconformidad con una gestión, y cumpliendo con las formalidades establecidas, a que se convoque el organismo que eligió a un/a funcionario/a,
para que sus integrantes voten por el cese o continuidad del mismo.

por el Consejo Universitario

S)
61. Semestre Académico:
En sentido docente, es el período de clases en que se ofrecen los cursos
universitarios en la Universidad Autónoma de Santo Domingo, que tiene
una duración de 16 semanas de docencia y un período de 2 semanas
para exámenes finales.
En sentido laboral, es el período por el cual se contrata a los profesores de la Universidad Autónoma de Santo Domingo, cuya duración
se extiende desde el inicio formal de un semestre hasta el inicio del
siguiente semestre.

62. Servicio Académico:
Antigüedad en el servicio en la Universidad, contados a partir de
la fecha de nombramiento aprobado por el Consejo Universitario.

T)
63. Título:
Título profesional

Constancia otorgada por la Universidad a sus egresados como prueba de
que han cumplido con todos los requisitos establecidos por la Institución,
que les habilita para ejercer una profesión o solicitar autorización para ello.
Título honorífico

Constancia otorgada por la Universidad a nacionales o extranjeros que
se han distinguido por sus aportes a las artes, las ciencias, o las humanidades.

 

Glosario Aprobado

64. Transparencia:
Es un principio de la gestión pública que se expresa en la publicación
permanente de los resultados del trabajo de las diferentes unidades y
organismos, y en la creación de instrumentos que faciliten el acceso de
todos los interesados a las informaciones producidas, de acuerdo con las
reglamentaciones internas y a la ley sobre la materia.

U)
65. Unidades:
Son estructuras pertenecientes a un organismo del área académica, del
gobierno y de la administración de la Universidad, que realizán funciones
específicas.

Este Estatuto Orgánico de la
Universidad Autónoma de Santo Domingo,
con una tirada de 1,000 ejemplares,
se terminó de imprimir en los
talleres gráficos de la Editora Universitaria,
en el mes septiembre del año 2015.
`;
