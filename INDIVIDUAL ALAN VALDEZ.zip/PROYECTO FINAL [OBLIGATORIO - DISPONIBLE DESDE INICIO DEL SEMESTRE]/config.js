// pega tu key de gemini aqui (este archivo NO se sube a github)
const API_KEY = "PEGA AQUI TU API KEY DE GEMINI";
const MODELOS = [
  "gemini-3.8-flash",
  "gemini-3.5-flash-lite"
];