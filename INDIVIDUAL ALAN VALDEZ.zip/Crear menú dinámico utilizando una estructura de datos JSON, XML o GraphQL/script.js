let listaOpciones = [];
const menuUl = document.getElementById("menu");
const formulario = document.getElementById("form-menu");

// lee los datos iniciales desde menu.json
fetch("menu.json")
  .then(res => res.json())
  .then(datos => {
    listaOpciones = datos.menu;
    dibujarMenu();
  });

// aqui se crean los elementos html del menu 
function dibujarMenu() {
  menuUl.innerHTML = "";

  listaOpciones.forEach(opcion => {
    const li = document.createElement("li");

    const enlace = document.createElement("a");
    enlace.href = opcion.enlace;
    enlace.textContent = opcion.nombre;
    li.appendChild(enlace);



    // dibuja el submenu en el json
    if (opcion.submenu && opcion.submenu.length > 0) {
      const subUl = document.createElement("ul");
      subUl.className = "submenu";

      opcion.submenu.forEach(sub => {
        const subLi = document.createElement("li");
        const subEnlace = document.createElement("a");
        subEnlace.href = sub.enlace;
        subEnlace.textContent = sub.nombre;
        subLi.appendChild(subEnlace);
        subUl.appendChild(subLi);
      });




      li.appendChild(subUl);


    }

    // boton para eliminar la opcion sin recargar
    const btnBorrar = document.createElement("button");
    btnBorrar.textContent = "x";
    btnBorrar.className = "btn-borrar";
    btnBorrar.onclick = () => {
      listaOpciones = listaOpciones.filter(item => item.id !== opcion.id);
      dibujarMenu();
    };
    li.appendChild(btnBorrar);

    menuUl.appendChild(li);
  });
}



// agrega una nueva opcion desde el formulario
formulario.addEventListener("submit", e => {
  e.preventDefault();

  const id = Number(document.getElementById("opcion-id").value);
  const nombre = document.getElementById("opcion-nombre").value.trim();
  const enlace = document.getElementById("opcion-enlace").value.trim();



  // valida que el id no este repetido
  if (listaOpciones.some(item => item.id === id)) {
    alert("ese id ya existe, usa otro numero");
    return;
  }



  // valida que el enlace tenga un formato valido
  if (!enlace.startsWith("#") && !enlace.startsWith("/") && !enlace.startsWith("http")) {
    alert("el enlace debe empezar con #, / o http");
    return;
  }

  
  listaOpciones.push({ id, nombre, enlace });
  dibujarMenu();
  formulario.reset();
});